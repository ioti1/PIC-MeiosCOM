// Read-only acceptance run; emits aggregates only, never source records.
const fs=require('node:fs'),assert=require('node:assert/strict');
global.crypto=require('node:crypto').webcrypto;global.JSZip=require('../vendor/jszip.min.js');
const X=require('../src/xlsx.js'),M=require('../src/model.js'),R=require('../src/reconcile.js'),E=require('../src/export.js');
(async()=>{
 const args=process.argv.slice(2),paths=args.filter(a=>a!=='--export');
 if(paths.length!==2)throw Error('Informe os dois arquivos: público oficial e contatos.');
 const sources=[];
 for(let i=0;i<paths.length;i++){
  const bytes=fs.readFileSync(paths[i]),book=await X.read({name:'origem.xlsx',arrayBuffer:async()=>bytes}),sheet=Object.keys(book)[0];
  sources.push(M.prepareSource({id:await R.digest(bytes),role:i?'contacts':'official',filename:i?'contatos.xlsx':'publico.xlsx',book,snapshotDate:'2026-10-15'},sheet,1));
  console.log(JSON.stringify({stage:i+1,readRows:sources.at(-1).rows.length}));
 }
 const start=performance.now(),o=await R.prepareOfficial([sources[0]]),r=await R.processContacts(o,[sources[1]]);
 assert.equal(r.contacts.length+r.contactIgnored,sources[1].rows.length);
 assert.equal(r.bindings.length+r.officialIgnored,sources[0].rows.length);
 assert.equal(r.contactSummary.total,r.contactSummary.matched+r.contactSummary.orphans+r.contactSummary.missingKey);
 const counts={officialRows:r.officialInputRows,officialBlank:r.officialIgnored,participants:r.participants.length,identified:r.summary.identified,bindings:r.bindings.length,contacts:r.contacts.length,contactBlank:r.contactIgnored,matched:r.contactSummary.matched,orphans:r.contactSummary.orphans,missingKey:r.contactSummary.missingKey,noRegistry:r.summary.withoutRegistry,noEmail:r.summary.withoutEmail,noAny:r.summary.withoutAny,maxContacts:r.participants.reduce((n,p)=>Math.max(n,p.channels.length),0),types:r.contacts.reduce((s,c)=>(s[c.typeCode||'UNKNOWN']=(s[c.typeCode||'UNKNOWN']||0)+1,s),{}),withUser:r.contacts.filter(c=>c.registrationUser!=='Não informado').length,withValidDate:r.contacts.filter(c=>c.registrationDate).length,seconds:Math.round((performance.now()-start)/1000),heapMB:Math.round(process.memoryUsage().heapUsed/1048576)};
 console.log(JSON.stringify(counts,null,2));
 if(args.includes('--export')){
  const expectedIssues=r.participants.reduce((n,p)=>n+p.contextIssues.length,0)+r.contacts.reduce((n,c)=>n+c.issues.length,0);
  let tick=Date.now();const out=await E.generate({result:r,sources},'bi',null,p=>{if(Date.now()-tick>15000){console.log(JSON.stringify({exportPhase:p.phase}));tick=Date.now();}});
  assert.equal(out.extension,'zip');const bundle=await JSZip.loadAsync(await out.blob.arrayBuffer()),totals={};
  for(const name of Object.keys(bundle.files).filter(n=>/\.xlsx$/.test(n))){
   const nested=await JSZip.loadAsync(await bundle.file(name).async('uint8array'));
   for(const entry of Object.keys(nested.files).filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/.test(n))){
    const xml=await nested.file(entry).async('string'),rows=(xml.match(/<row\b/g)||[]).length-1,key=name.replace(/_\d{3}_.*/,'');
    totals[key]=(totals[key]||0)+rows;
   }
  }
  assert.equal(totals.Contatos,r.contacts.length);assert.equal(totals.Participantes,r.participants.length);assert.equal(totals.Vinculos_Oficiais,r.bindings.length);assert.equal(totals.Achados,expectedIssues);
  console.log(JSON.stringify({exportVerified:true,parts:out.parts,zipMB:Math.round(out.blob.size/1048576),totals,exportSeconds:Math.round((performance.now()-start)/1000)-counts.seconds},null,2));
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
