# Petros · Auditoria de Comunicação 2.0

Aplicação local em HTML, CSS e JavaScript. A versão anterior permanece na pasta original; esta entrega é independente e não altera os arquivos Excel de origem.

## Começar

1. Extraia a pasta inteira do ZIP. Mantenha `index.html`, `src`, `styles`, `assets` e `vendor` juntos.
2. Abra `index.html` em um navegador moderno de 64 bits. Não precisa instalar servidor nem ter conexão com a internet.
3. Na etapa **Público oficial**, adicione um ou mais arquivos XLSX, CSV ou TXT. Selecione cada fonte em **Mapeamento & fotografia**, revise aba, cabeçalho e associações.
4. **Preencha manualmente a fotografia de cada arquivo.** É a data à qual os dados se referem, e pode ser de meses ou anos anteriores. Ela não é extraída do nome do arquivo, da data de modificação, do dia de processamento ou da configuração salva.
5. Clique **1. Processar público oficial**. Somente após essa conclusão a carga dos contatos fica disponível.
6. Na etapa **Meios de comunicação**, adicione as bases de contatos, revise os campos, informe manualmente as fotografias correspondentes e clique **2. Validar todos os contatos**.
7. Explore o painel, a fila e as extrações. O botão de demonstração usa apenas dados fictícios e também exige a conclusão das duas etapas.

As duas etapas precisam conter as mesmas fotografias. Falta de arquivo não é interpretada como falta de contato. Se houver uma fotografia realmente sem contatos na origem, use um arquivo dessa fotografia com os cabeçalhos de contatos e nenhuma linha de dados.

Alterar a fonte oficial, sua fotografia ou seu mapeamento exige refazer a etapa 1 e depois a etapa 2. Alterar os contatos ou as regras exige refazer a etapa 2. Resultados obsoletos ficam indisponíveis para exportação.

## Papéis das bases

O público oficial determina o universo. O padrão de referência contém 20 campos: identificação, nome, patrocinadora, nascimento, idade, estado civil, endereço completo, óbito, plano, Matrícula Petros, situação, tipo de plano e benefício.

Os contatos têm uma linha por meio de comunicação, com os nove campos de referência: `MATRICULA_PETROS`, `NOME`, `SEQUENCIA_CONTATO`, `TIPO_CONTATO`, `DDD`, `TELEFONE_CELULAR`, `EMAIL`, `DATA_REGISTRO` e `USUARIO_REGISTRO`.

O nome do arquivo é livre. O mapeamento considera os cabeçalhos e, nos layouts de referência, a ordem das colunas. A ordem pode ser reaplicada pelo botão próprio; revise antes de processar. XLS legado não é suportado: salve como XLSX. Arquivos com o calendário Excel 1904 são bloqueados com orientação para salvar uma cópia no calendário 1900; isso evita deslocamento silencioso das datas. Uma fonte usa uma aba selecionada; arquivos adicionais podem ser concatenados.

Tipos: **TL** = telefone fixo; **CE** = celular; **EM** = e-mail. Não existe um número máximo de contatos por matrícula no modelo: todos os registros são preservados, inclusive repetições e tipos não reconhecidos.

## Conciliação e contagem

- Chave do participante: **Matrícula Petros + fotografia**. `Id PF` não substitui a Matrícula Petros.
- Matrículas numéricas com zeros à esquerda são conciliadas, mantendo o valor original nos dados de origem/exportação. Chaves alfanuméricas continuam textuais.
- Uma matrícula com mais de um plano ou vínculo continua sendo um participante na fotografia. Os vínculos oficiais permanecem separados; os contatos não são multiplicados pelo número de vínculos.
- Quem consta no público, mas não tem nenhuma linha de contato correspondente, permanece no universo com **Sem registro de comunicação**.
- Contatos fora do público são validados e preservados com a conciliação **Fora do público oficial**. Não entram no denominador de participantes.
- Linhas sem matrícula ficam sinalizadas. Ausência de chave não autoriza concluir exclusão digital.
- Linhas realmente vazias são contabilizadas separadamente e ignoradas na validação; linhas com metadados, ainda que sem meio de contato, são preservadas.
- Filtros simultâneos de plano/patrocinadora/grupo exigem correspondência no mesmo vínculo, evitando combinações artificiais entre vínculos diferentes.

Não some participantes entre planos, patrocinadoras ou fotografias. Use contagem distinta dentro de uma fotografia/execução selecionada.

## Inclusão digital e alcance

São critérios independentes e sobrepostos:

| Filtro | Definição |
| --- | --- |
| Sem registro na base de contatos | Nenhuma linha correspondente à matrícula/fotografia |
| Sem qualquer meio cadastrado | Nenhum valor de telefone, celular ou e-mail nos contatos vinculados |
| Excluído digital: sem e-mail cadastrado | Nenhum valor de e-mail cadastrado, mesmo que existam números |
| Sem e-mail e sem telefone fixo | Nenhum e-mail e nenhum TL preenchido |
| Sem e-mail e sem telefone/celular | Nenhum e-mail e nenhum número TL/CE preenchido |
| Sem e-mail e sem celular | Nenhum e-mail e nenhum CE preenchido |
| Sem e-mail ou celular estruturalmente válido | Nenhum EM válido e nenhum CE válido segundo o motor estrutural |
| E-mail cadastrado, nenhum válido | Existe valor de e-mail, mas nenhum atende à estrutura |

Cadastro e validade não são equivalentes: um e-mail inválido não é contado como e-mail ausente. Uma linha apenas com DDD não constitui número cadastrado. Tipo desconhecido preenchido torna a classificação de ausência incerta, explicitada em `Exclusao_Incerta`; revise esses casos antes de concluir exclusão digital. O filtro de estrutura válida considera apenas os tipos reconhecidos.

## Regras e tratamento

As regras existentes de DDD, telefone, celular e e-mail são mantidas. Há seleção global e por grupo. Foram acrescentadas conciliação, presença do valor, tipo reconhecido, usuário e data do cadastro.

DDD `0071` é normalizado para `71`, sem alerta apenas pelos zeros à esquerda. DDD ausente e inexistente têm mensagens específicas. Quantidade de dígitos informa o número observado, esperado, faltante ou excedente. E-mail recebe a descrição do defeito encontrado, sem complemento genérico de múltiplos endereços quando o defeito não é esse.

Validade é **pré-validação estrutural**: não comprova entrega, titularidade, linha ativa ou endereço de e-mail existente. Sugestões não alteram a origem. Desmarcar uma regra remove seu apontamento, mas não transforma um canal estruturalmente inválido em válido para a cobertura.

A fila alterna **Meios de comunicação** e **Participantes & ausências**. Esta última é a visão adequada para quem não tem contato algum. Os filtros incluem fotografia, grupo/subgrupo, plano, patrocinadora, faixa etária, UF/cidade, resultado, cobertura, inclusão, usuário e intervalo de cadastro. Regra/problema oferecem somente opções presentes no recorte. Na visão de participantes, os filtros específicos do contato significam “possui ao menos um contato correspondente”.

Paginação: 20 ou 100 linhas, ou **Todos (progressivo)**, carregando mil por vez. A extração não se limita à página visível.

**Tratado** encerra pendências operacionais sem apagar o erro ou alterar o dado. Pode ser aplicado por contato ou ao conjunto do participante. É reversível. **Salvar andamento** baixa um JSON; **Restaurar andamento** retoma marcas compatíveis com as mesmas fontes, fotografias, mapeamentos e regras. Arquivos/regras diferentes não recebem marcas antigas automaticamente. A versão 1 usa outro modelo e seu andamento não é importado silenciosamente na versão 2.

Não há gravação automática das bases ou das marcas ao fechar o navegador. Salve o andamento e os resultados antes de sair. O JSON de andamento também contém identificadores: armazene-o com o mesmo cuidado dos relatórios.

## As três datas

- **Data_Fotografia:** preenchida pelo operador, por fonte; compõe a conciliação, a idade de referência e o histórico. Continua sendo a data histórica escolhida quando houver reprocessamento.
- **Data_Cadastro:** data/hora do registro do contato na origem, acompanhada de `Usuario_Cadastro`. O original é preservado, inclusive quando não pode ser interpretado. O padrão textual esperado é brasileiro DD/MM/AAAA, com hora opcional; também são lidos ISO e datas seriais do Excel. Não é inferido fuso horário de datas sem fuso. Valores ambíguos ou inválidos não são “corrigidos” para datas americanas.
- **Processado_Em_UTC / emissão do PDF:** quando a execução/relatório foi produzido; não substitui a fotografia.

Nascimento é exibido/exportado em DD/MM/AAAA. A idade é calculada em relação à fotografia, usando nascimento válido quando disponível; a origem da idade e a idade informada permanecem rastreáveis.

## Excel, PDF e Power BI

**Acompanhamento completo** inclui Participantes, Vinculos_Oficiais, Contatos, Achados, Indicadores, Cadastro_Por_Usuario, Execucao, Fontes e Regras. **Todos os contatos** é a extração operacional de meios de comunicação. **Excel deste recorte** respeita filtros e visão, sem limitar à paginação, e identifica o escopo como parcial.

As colunas de validação são próprias e destacadas em outra cor; não substituem nome, telefone ou e-mail. Os arquivos possuem cabeçalho congelado, filtros e datas nativas do Excel. Valores importados não são executados como fórmulas.

Bases extensas geram um ZIP contendo blocos XLSX de até 25 mil linhas de dados, além de um arquivo Contexto com fontes, regras e execução. Combine todos os blocos da mesma tabela; eles não são amostras. O arquivo gerado fica em Downloads, conforme a configuração do navegador.

O **PDF** usa os filtros do painel, mostra a fotografia manual, a data de emissão, critérios de inclusão, grupos, subgrupos, planos e patrocinadoras. Escolha “Salvar como PDF” na impressão. As seções explicitamente completas (fontes e conciliação) usam toda a execução, não o recorte. O detalhamento por contato e usuário/data deve ser obtido no Excel.

Veja [POWERBI.md](POWERBI.md) para o modelo histórico e cuidados com denominadores.

## Privacidade, capacidade e verificação

O processamento usa bibliotecas incluídas na pasta, sem upload, API, consulta externa de e-mail/telefone ou carregamento de fontes remotas. Bases/relatórios contêm dados pessoais e devem permanecer em local autorizado pela instituição.

O modelo não limita contatos por pessoa, mas a capacidade física depende da memória do computador/navegador. As bases completas fornecidas foram processadas e a extração conferida em teste automatizado local; isso não é garantia de desempenho em qualquer computador. Para volumes muito superiores, será recomendável uma futura arquitetura com persistência e processamento em segundo plano.

Testes e limites de verificação estão em [VERIFICACAO.md](VERIFICACAO.md). A inspeção visual no navegador e a paginação final do PDF não foram confirmadas nesta execução: não considere essa parte homologada apenas pelos testes de lógica.
