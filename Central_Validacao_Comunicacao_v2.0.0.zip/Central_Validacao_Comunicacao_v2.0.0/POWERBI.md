# Acompanhamento da qualidade cadastral · versão 2

Tema sugerido: **Alcance & Confiança Cadastral**. Fundo claro, azul institucional para universo, verde-petróleo para canais válidos, âmbar para revisão e vermelho apenas para inconsistência. Use a mesma tipografia Segoe UI e as logos locais da aplicação.

## Modelo de dados

| Tabela | Grão | Uso |
| --- | --- | --- |
| Participantes | Matrícula Petros/fotografia/execução | Denominador oficial, cobertura, inclusão e andamento |
| Vinculos_Oficiais | Cada linha da base oficial | Plano, patrocinadora, situação, benefício, endereço e proveniência |
| Contatos | Cada linha da base de contatos | Todos os TL/CE/EM, inclusive externos, com usuário/data originais |
| Achados | Cada apontamento, de contexto ou contato | Matriz risco/problema, regra, severidade e tratamento |
| Indicadores | Fotografia/dimensão/categoria | Agregados prontos; não somar categorias sobrepostas |
| Cadastro_Por_Usuario | Fotografia/usuário/dia do cadastro | Auditoria da origem dos lotes |
| Execucao, Fontes, Regras | Metadados | Escopo, reprocessamento, fotografia e configuração |

No Power Query, combine todos os blocos XLSX de cada tabela e mantenha somente um cabeçalho por arquivo. `Contexto` não deve ser concatenado à tabela de contatos. Colunas de data devem ter os tipos Data e Data/Hora apropriados, usando localidade pt-BR quando necessário. Matrícula e identificadores devem permanecer como texto.

Crie uma chave composta como texto em Participantes, Contatos, Vinculos_Oficiais e Achados: `Id_Execucao & "|" & Id_Participante`. Em Contatos e Achados, deixe essa chave nula quando Id_Participante estiver vazio. Relacione Participantes (lado 1) às demais tabelas (lado muitos) usando essa chave, não apenas o número da matrícula.

Para detalhar achados de um contato, use `Id_Execucao & "|" & Id_Contato`. Não crie caminhos de filtro redundantes que tornem o modelo ambíguo. Linhas de contexto de participante não têm Id_Contato. Contatos fora do público não têm Id_Participante e devem ter uma página própria de conciliação.

Use tabelas de calendário separadas para **fotografia** e **cadastro do contato**, com papéis distintos. Selecionar mês de cadastro não deve alterar inadvertidamente o denominador oficial da fotografia.

Planos e patrocinadoras podem ter mais de um vínculo por participante. Aplique um filtro desses atributos formando primeiro o conjunto de chaves de participantes nos vínculos e depois filtrando os fatos por esse conjunto. Para plano + patrocinadora, a interseção deve ocorrer no mesmo vínculo. Não duplique a tabela Contatos juntando-a diretamente a todos os vínculos.

## Histórico de reprocessamentos

Uma fotografia pode ser processada várias vezes, gerando diferentes `Id_Execucao`. Guarde os arquivos históricos, mas escolha uma execução homologada por fotografia para a visão oficial. Caso contrário, o mesmo público será contado novamente.

`Universo_Oficial_Completo = 1` identifica a extração integral. Exporte o PBI pelo botão de acompanhamento completo. Recortes da fila são úteis para investigação, mas não devem substituir a base oficial de indicadores.

O status Tratado mede encerramento operacional, não saneamento comprovado. A evolução de qualidade deve vir de nova fotografia/reprocessamento da origem, e não da simples marcação de pendências.

## Páginas sugeridas

1. **Direção · Alcance do público.** Seletor de fotografia homologada, grupo/subgrupo, plano e patrocinadora. Cartões: participantes oficiais, sem registro de comunicação, sem e-mail, sem qualquer meio, com ao menos um canal válido. Barras por grupo/plano e uma matriz por patrocinadora. Separe volume de contato e volume de pessoas.
2. **Evolução.** Série mensal de fotografia com taxas de ausência e cobertura; denominador e regras documentados. Mudanças de regras/composição do público precisam aparecer como notas para não sugerir melhoria sem comparabilidade.
3. **Auditoria de origem.** Usuário de cadastro × dia/mês de cadastro, quantidade de contatos, contatos com erro, proporção de erro e principais problemas. Use contagens de contatos, não de participantes, e trate usuário não informado como categoria própria. Evite interpretação de produtividade ou causalidade sem contexto operacional.
4. **Tratamento.** Pendentes/tratados, matriz risco → problema → regra, lote por usuário/data, plano e patrocinadora. Exiba original, normalizado e sugestão em campos diferentes.
5. **Conciliação e qualidade do público.** Contatos externos, matrículas ausentes, tipos desconhecidos, vínculos repetidos e divergências cadastrais. Mantenha esses volumes visíveis sem inflar o universo oficial.

Taxa sem e-mail = participantes oficiais identificados sem e-mail / participantes oficiais identificados, na mesma fotografia/recorte. Taxa de canal válido usa pessoas com ao menos um canal estruturalmente válido. Para qualidade por usuário, use contatos com erro / contatos do usuário, mostrando também o volume absoluto.

As classificações de exclusão se sobrepõem. Não faça um gráfico de pizza somando “sem e-mail”, “sem registro” e “sem qualquer meio”. Use barras independentes com a definição no tooltip. Preserve na visão de auditoria os casos `Exclusao_Incerta = 1`.
