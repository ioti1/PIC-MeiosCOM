const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8'),ids=[...html.matchAll(/id="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);
for(const m of html.matchAll(/(?:src|href)="([^"]+)"/g)){const ref=m[1];if(ref==='#')continue;assert.ok(!/^https?:/.test(ref),'Remote dependency '+ref);assert.ok(fs.existsSync(path.join(root,ref)),'Missing '+ref);}
for(const file of fs.readdirSync(path.join(root,'src')).filter(f=>f.endsWith('.js')))new vm.Script(fs.readFileSync(path.join(root,'src',file),'utf8'),{filename:file});
assert.match(html,/id="snapshotDate" type="date" required/);assert.doesNotMatch(html,/id="snapshotDate"[^>]*value=/);console.log('✓ Referências locais, identificadores únicos, sintaxe JavaScript e fotografia sem preenchimento automático');
