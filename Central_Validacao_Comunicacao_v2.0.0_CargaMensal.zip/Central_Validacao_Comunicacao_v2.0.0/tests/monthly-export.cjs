const assert=require('node:assert/strict');global.crypto=require('node:crypto').webcrypto;global.JSZip=require('../vendor/jszip.min.js');
const M=require('../src/model.js'),R=require('../src/reconcile.js'),E=require('../src/monthly-export.js'),X=require('../src/xlsx.js');
const source=(role,rows,date)=>M.prepareSource({id:role+date,role,filename:role+'.xlsx',snapshotDate:date,book:{Dados:[M.fields[role].map(f=>f.label),...rows]}},'Dados',1);
async function state(date){const p=source('official',[['1','Pessoa fictícia','Patrocinadora','20/05/1980','','','','','','','','','','','-','Plano A',1,'Ativo','BD','']],date),c=source('contacts',Array.from({length:16},(_,i)=>[1,'Pessoa fictícia',i+1,'EM','','',`p${i}@dominio-demo.org`,date+' 10:20:30','operador.demo']),date),o=await R.prepareOfficial([p]);return {result:await R.processContacts(o,[c]),sources:[p,c]};}
function total(book,base){return Object.entries(book).filter(([n])=>n===base||new RegExp('^'+base+'_\\d+$').test(n)).reduce((n,[,rows])=>n+rows.length-1,0);}
(async()=>{
 assert.throws(()=>E.check({}),/Conclua/);console.log('✓ Arquivo mensal exige as duas etapas concluídas');
 const s=await state('2024-06-30'),out=await E.generate(s,null,{chunkRows:3}),bytes=new Uint8Array(await out.blob.arrayBuffer()),zip=await JSZip.loadAsync(bytes,{checkCRC32:true}),book=await X.read({name:out.filename,arrayBuffer:async()=>bytes});
 if(process.argv[2])require('node:fs').writeFileSync(process.argv[2],bytes);
 assert.equal(out.filename,'PETROS_PBI_MENSAL_2024-06.xlsx');assert.equal(total(book,'Contatos'),16);assert.equal(total(book,'Participantes'),1);assert.ok(book.Contatos_6);console.log('✓ Um XLSX mensal reúne todas as abas/partes sem cortar contatos');
 const ex=book.Execucao,header=ex[0],row=ex[1];assert.equal(row[header.indexOf('Contrato_PBI_Mensal')],'1');assert.equal(row[header.indexOf('Universo_Oficial_Completo')],'1');assert.equal(row[header.indexOf('Competencia')],'2024-06');assert.equal(row[header.indexOf('Fotografias')],'2024-06-30');console.log('✓ Contrato identifica universo completo e fotografia histórica, não data atual');
 assert.equal(Object.keys(zip.files).filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/.test(n)).length,out.sheets.length);console.log('✓ Pacote XLSX tem integridade CRC e todas as relações de abas');
 const newer=await E.generate(await state('2024-07-31'));assert.notEqual(newer.filename,out.filename);const again=await E.generate(s);assert.equal(again.filename,out.filename);const folder=new Map([[out.filename,out],[newer.filename,newer]]);folder.set(again.filename,again);assert.equal(folder.size,2);console.log('✓ Novo mês acrescenta arquivo; reprocessamento mantém nome para substituição');
 s.result.photos.push('2024-07-31');await assert.rejects(()=>E.generate(s),/única fotografia/);console.log('✓ Múltiplas fotografias não são misturadas em um arquivo mensal');
})();
