const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),E=require('../src/export.js');
const dir=path.join(__dirname,'../PowerBI_Mensal'),dax=fs.readFileSync(path.join(dir,'04_Medidas_Mensais.dax'),'utf8');
const definitions=new Set([...dax.matchAll(/^([A-Za-z][A-Za-z0-9 ]*) =$/gm)].map(m=>m[1]));
for(const [,ref] of dax.matchAll(/(?<![A-Za-z0-9_])\[([A-Za-z][A-Za-z0-9_ ]*)\]/g))assert.ok(definitions.has(ref),'Medida não definida: '+ref);
const schema={Participantes:new Set(E.participantRows({},[]).next().value),Vinculos_Oficiais:new Set(E.bindingRows({},[]).next().value),Contatos:new Set(E.contactRows({},[]).next().value),Achados:new Set(E.issueRows({},[],[]).next().value),Fotografias:new Set(['Mes_Referencia','Data_Fotografia','AnoMes','Perfil_Regras'])};
for(const name of ['Participantes','Vinculos_Oficiais','Contatos','Achados'])for(const extra of ['Mes_Referencia','Arquivo_PBI','ChaveParticipante','ChaveContato'])schema[name].add(extra);
for(const [,table,col] of dax.matchAll(/([A-Za-z_]\w*)\[([^\]]+)\]/g))assert.ok(schema[table]?.has(col),'Coluna não declarada: '+table+'['+col+']');
console.log('✓ Todas as medidas e colunas referenciadas existem no contrato mensal');
const arq=fs.readFileSync(path.join(dir,'01_ArquivosPBI.m'),'utf8'),fn=fs.readFileSync(path.join(dir,'02_fnTabelaPBI.m'),'utf8'),foto=fs.readFileSync(path.join(dir,'03_Fotografias.m'),'utf8');
assert.match(arq,/Folder\.Contents/);assert.ok(!arq.includes('Folder.Files'));assert.ok(arq.includes('Contrato_PBI_Mensal')&&arq.includes('Universo_Oficial_Completo'));assert.ok(arq.includes('Duplicados'));assert.ok(fn.includes('Table.Combine(Promovidas)'));assert.ok(fn.includes('MesmoEsquema'));assert.ok(foto.includes('Sem arquivo'));
console.log('✓ Receitas incluem carga de uma pasta, todas as abas, contrato completo e mês ausente');
function previous(month){const [y,m]=month.split('-').map(Number),d=new Date(Date.UTC(y,m-2,1));return d.toISOString().slice(0,7);}
const history=new Map([['2025-12',{rate:.10,profile:'A'}],['2026-01',{rate:.08,profile:'A'}],['2026-03',{rate:.06,profile:'B'}]]);
function compare(month){const current=history.get(month),prev=history.get(previous(month));return current&&prev&&current.profile===prev.profile?100*(current.rate-prev.rate):null;}
assert.equal(previous('2026-01'),'2025-12');assert.ok(Math.abs(compare('2026-01')+2)<1e-9);assert.equal(compare('2026-03'),null);history.set('2026-02',{rate:.07,profile:'A'});assert.equal(compare('2026-03'),null);
console.log('✓ Caso de referência: virada de ano, mês faltante e alteração de regras não geram comparação enganosa');
console.log('Revisão estática e casos de referência: não substituem executar M/DAX no Power BI Desktop.');
