(function(root,factory){const S=typeof module==='object'&&module.exports?require('./schema.js'):root.ComSchema;const api=factory(S);if(typeof module==='object'&&module.exports)module.exports=api;else root.ComAudit=api;})(globalThis,function(S){
  'use strict';
  const str=v=>v==null?'':String(v).trim();
  const norm=v=>str(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
  const digits=v=>str(v).replace(/\D/g,'');
  function isMissing(v){return !str(v)||['-','--','NULL','(NULL)','N/A','NAN','NONE'].includes(norm(v));}
  function isMissingDate(v){return isMissing(v)||['00/00/0000','0000-00-00','00000000'].includes(str(v));}
  const category=v=>isMissing(v)?'':str(v);
  function date(v){if(v instanceof Date)return Number.isNaN(+v)?null:v;const t=str(v);if(!t)return null;if(/^\d+(\.\d+)?$/.test(t)&&+t>0&&+t<100000)return new Date(Math.floor(+t-25569)*86400000);let m=t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!m){m=t.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);if(m)m=[m[0],m[3],m[2],m[1]];}if(!m)return null;const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return d.getUTCFullYear()===+m[1]&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[3]?d:null;}
  function ageAt(d,ref){if(!d||!ref||d>ref)return null;return ref.getUTCFullYear()-d.getUTCFullYear()-(ref.getUTCMonth()<d.getUTCMonth()||(ref.getUTCMonth()===d.getUTCMonth()&&ref.getUTCDate()<d.getUTCDate())?1:0);}
  function ageBand(n){return n==null?'Não disponível':n<0||n>120?'Fora do intervalo':n<18?'Até 17':n<30?'18–29':n<45?'30–44':n<60?'45–59':n<75?'60–74':'75+';}
  function autoMap(headers){const result={};const used=new Set();const clean=headers.map(norm);S.fields.forEach(f=>{let i=clean.findIndex((h,j)=>!used.has(j)&&h===norm(f.label));if(i<0&&headers.length===23)i=f.index;if(i>=0){result[f.id]=i;used.add(i);}});return result;}
  const typos={'gamil.com':'gmail.com','gmial.com':'gmail.com','gmail.con':'gmail.com','gmail.com.br':'gmail.com','hotmai.com':'hotmail.com','hotmial.com':'hotmail.com','hotmail.con':'hotmail.com','outlok.com':'outlook.com','outlook.con':'outlook.com','yahoo.con':'yahoo.com'};
  function issueDetails(rule,details={}){const base=S.issueTaxonomy[rule]||{};const code=details.problemCode||(S.problemLabels[details.problem]?details.problem:base.problemCode);return {...base,...details,problemCode:code,problem:details.problem?(S.problemLabels[details.problem]||details.problem):base.problem};}
  function classifyContract(situacao,beneficio){
    const s=norm(situacao).replace(/\s*[-–—]\s*/g,'-').replace(/\s+/g,' ');
    const active={ATIVO:'Ativo',ATIVOS:'Ativo',REMIDO:'Remido',REMIDOS:'Remido',AUTOPATROCINADO:'Autopatrocinado',AUTOPATROCINADOS:'Autopatrocinado','OPTANTE PELO BPO':'Optante pelo BPO','ATIVO-AGUARDANDO DEFERIMENTO':'Ativo-Aguardando Deferimento','ATIVO AGUARDANDO DEFERIMENTO':'Ativo-Aguardando Deferimento','EX-AGUARDANDO DEFERIMENTO':'Ex-Aguardando Deferimento','EX AGUARDANDO DEFERIMENTO':'Ex-Aguardando Deferimento','EX-PARTICIPANTE AGUARDANDO DEFERIMENTO':'Ex-Aguardando Deferimento','EX-PARTICIPANTE-AGUARDANDO DEFERIMENTO':'Ex-Aguardando Deferimento','ASSISTIDO-AGUARDANDO DEFERIMENTO':'Assistido-Aguardando Deferimento','ASSISTIDO AGUARDANDO DEFERIMENTO':'Assistido-Aguardando Deferimento'};
    if(active[s])return {contractGroup:'Ativos',contractSubgroup:active[s]};
    if(/^(ASSISTIDO|ASSISTIDOS|ASSISTIDA|ASSISTIDAS|APOSENTADO|APOSENTADOS|APOSENTADA|APOSENTADAS|APOSENTADO\(A\)|PENSIONISTA|PENSIONISTAS)$/.test(s))return {contractGroup:'Assistidos',contractSubgroup:norm(beneficio).includes('PENS')?'Pensionista':'Aposentado(a)'};
    return {contractGroup:'Não classificado',contractSubgroup:isMissing(situacao)?'Situação não informada':str(situacao)};
  }
  function emailSyntaxProblem(value){
    const t=str(value), ats=(t.match(/@/g)||[]).length;
    const issue=(problem,message)=>({problem,message});
    if(/[;,]/.test(t))return issue('email_separador_invalido','E-mail contém ponto e vírgula ou vírgula, separadores incompatíveis com a estrutura do endereço.');
    if(!ats)return issue('email_arroba_ausente','E-mail sem o símbolo @ que separa o nome da caixa e o domínio.');
    if(ats>1)return issue('email_arroba_multipla',`E-mail contém ${ats} símbolos @; a estrutura permite exatamente um.`);
    const [local,domain]=t.split('@');
    if(!local)return issue('email_caixa_ausente','E-mail sem o nome da caixa antes de @.');
    if(!domain)return issue('email_dominio_ausente','E-mail sem domínio após @.');
    if(/\s/.test(t))return issue('email_espaco_interno','E-mail contém espaço ou quebra de linha dentro do endereço.');
    if(t.length>254)return issue('email_excede_limite',`E-mail contém ${t.length} caracteres e excede o limite de 254 em ${t.length-254}.`);
    if(local.length>64)return issue('email_caixa_excede_limite',`Nome da caixa contém ${local.length} caracteres e excede o limite de 64 em ${local.length-64}.`);
    if(local.startsWith('.')||local.endsWith('.')||local.includes('..'))return issue('email_pontos_caixa','Nome da caixa contém ponto inicial, final ou pontos consecutivos.');
    if(!/^[A-Za-z0-9.!#$%&'*+\-/=?^_`{|}~]+$/.test(local))return issue('email_caractere_caixa','Nome da caixa contém caractere incompatível com o padrão de e-mail.');
    if(!domain.includes('.'))return issue('email_dominio_sem_ponto','Domínio do e-mail não contém ponto e extensão, como empresa.com.br.');
    const labels=domain.split('.');
    if(labels.some(p=>!p))return issue('email_pontos_dominio','Domínio contém ponto inicial, final ou pontos consecutivos.');
    const long=labels.find(p=>p.length>63);if(long)return issue('email_rotulo_dominio_excede_limite',`Parte do domínio contém ${long.length} caracteres e excede o limite de 63 em ${long.length-63}.`);
    if(labels.some(p=>!/^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/.test(p)))return issue('email_caractere_dominio','Domínio contém caractere inválido ou hífen no início/fim de uma de suas partes.');
    if(!/^[a-z]{2,}$/i.test(labels[labels.length-1]))return issue('email_extensao_invalida','Extensão final do domínio deve conter pelo menos duas letras.');
    return null;
  }
  function checkChannel(ch,raw,dddRaw,mapped=true,dddMapped=true){
    const t=isMissing(raw)?'':str(raw), dr=isMissing(dddRaw)?'':str(dddRaw), findings=[];
    const add=(rule,message,suggestion='',details={})=>findings.push({rule,message,suggestion,...issueDetails(rule,details)});
    if(!mapped)return {id:ch.id,type:ch.type,label:ch.label,present:false,valid:null,normalized:'',findings:[],state:'Não avaliado',raw:'',ddd:''};
    let normalized='',valid=false,present=!!t,uf='';
    if(ch.type==='email'){
      const at=t.lastIndexOf('@');const local=at<0?t:t.slice(0,at);const domain=at<0?'':t.slice(at+1).toLowerCase();normalized=at<0?t:local+'@'+domain;
      if(t){
        const syntaxProblem=emailSyntaxProblem(t),syntax=!syntaxProblem;
        const dummy=/^(teste\d*|test\d*|sememail|naoinformado|naopossui|xxx|abc)$/i.test(norm(local).replace(/[ ._-]/g,''))||['example.com','example.org','exemplo.com','teste.com'].includes(domain)||['NAO INFORMADO','SEM EMAIL','N/A','NAO POSSUI'].includes(norm(t));
        if(syntaxProblem)add('email_syntax',syntaxProblem.message,'',{problem:syntaxProblem.problem});
        if(dummy)add('email_dummy','Endereço pode indicar exemplo ou ausência de informação; confirmar legitimidade.');
        if(String(raw)!==t||t!==normalized)add('email_format','Padronizar espaços externos e domínio do e-mail.',normalized);
        if(typos[domain])add('email_typo','Domínio possivelmente incorreto; confirmar com o participante.',local+'@'+typos[domain]);
        valid=syntax;
      }
    }else{
      let number=digits(t),ddd=digits(dr);const size=ch.type==='celular'?9:8;
      if(/^0+\d{2}$/.test(ddd))ddd=ddd.slice(-2);
      const original=number;
      if(ddd.length===3&&ddd.startsWith('0'))ddd=ddd.slice(1);
      if((number.length===12||number.length===13)&&number.startsWith('55')&&S.dddUF[number.slice(2,4)])number=number.slice(2);
      if(number.length===10||number.length===11){const embedded=number.slice(0,2);if(S.dddUF[embedded]){if(!ddd){ddd=embedded;number=number.slice(2);}else if(ddd===embedded)number=number.slice(2);else if(number.length===size+2){add('pair',`DDD ${ddd} informado no campo difere do DDD ${embedded} incorporado no número.`,'',{problem:'ddd_divergente'});number=number.slice(2);}}}
      const okDDD=!!S.dddUF[ddd]&&/^\d{2}$/.test(ddd);uf=S.dddUF[ddd]||'';
      normalized=number;present=!!t||!!dr;
      if(present){
        if(!t||(!ddd&&!dr&&t))add('pair',!t?'DDD preenchido sem número telefônico.':'DDD ausente: número local preenchido sem o código de área.','',{problem:!t?'numero_ausente':'ddd_ausente'});
        if(dr&&!okDDD)add('ddd',`DDD ${ddd||dr} não corresponde a um código brasileiro existente com dois dígitos.`,'',{problem:ddd.length===2?'ddd_inexistente':'ddd_quantidade_digitos',observedDigits:ddd.length,expectedDigits:2,digitDelta:ddd.length-2});
        if(t&&number.length!==size){const delta=number.length-size,amount=Math.abs(delta),missing=amount===1?'Falta':'Faltam',extra=amount===1?'Excede':'Excedem',problem=`${delta<0?missing:extra} ${amount} dígito${amount===1?'':'s'}`;add('length',`${ch.type==='celular'?'Celular':'Telefone fixo'} com ${number.length} dígitos; ${problem.toLowerCase()} para o padrão de ${size} dígitos, sem DDD.`,'',{problem,problemCode:delta<0?'digitos_faltantes':'digitos_excedentes',observedDigits:number.length,expectedDigits:size,digitDelta:delta});}
        if(t&&!(ch.type==='celular'?/^9/:/^[2-5]/).test(number))add('prefix',ch.type==='celular'?'Celular deve iniciar em 9.':'Telefone fixo deve iniciar em 2, 3, 4 ou 5.','',{problem:ch.type==='celular'?'prefixo_celular_invalido':'prefixo_fixo_invalido'});
        if((t&&!/^\+?[\d\s().-]+$/.test(t))||(dr&&!/^[\d\s()-]+$/.test(dr)))add('characters','Há texto ou separadores incompatíveis com um único número.');
        if(t&&(/^(\d)\1+$/.test(number)||['12345678','123456789','987654321','912345678'].includes(number)))add('dummy','Número repetitivo ou sequência típica de exemplo; confirmar legitimidade.');
        const neutralDDD=/^0+\d{2}$/.test(dr)&&digits(dr).slice(-2)===ddd;
        if(t&&(t!==number||(dr!==ddd&&!neutralDDD)||original!==number))add('format',`Padronizar número e DDD em campos separados${!dddMapped?' (coluna DDD não mapeada)':''}.`,`DDD ${ddd}; número ${number}`);
        valid=!!t&&!findings.some(f=>!['format','dummy'].includes(f.rule));
      }
      return {id:ch.id,type:ch.type,label:ch.label,present,valid:present?valid:false,normalized,ddd,uf,raw:str(raw),findings,state:present?(valid?'Válido':'Inválido'):'Ausente'};
    }
    return {id:ch.id,type:ch.type,label:ch.label,present,valid:present?valid:false,normalized,ddd:'',uf,raw:str(raw),findings,state:present?(valid?'Válido':'Inválido'):'Ausente'};
  }
  async function process({rows,mapping,selection,referenceDate,firstDataRow=2,onProgress,cancelled,provenance=[]}){
    const selected=new Set(selection||S.rules.map(r=>r.id));const definitions=Object.fromEntries(S.rules.map(r=>[r.id,r]));
    const ref=date(referenceDate)||new Date();const records=[];const owners=new Map();const identities=new Map();const people=new Set();const recordIds=new Set();let ignored=0;
    const mappedChannels=S.channels.filter(c=>mapping[c.id]!=null).length;
    for(let i=0;i<rows.length;i++){
      if(cancelled?.())throw new Error('Processamento cancelado.');
      const row=rows[i];if(row.every(v=>!str(v))){ignored++;continue;}
      const origin=provenance[i]||{},sourceFields=Array.isArray(origin.mappedFields)?new Set(origin.mappedFields):null;
      const isMapped=id=>mapping[id]!=null&&(!sourceFields||sourceFields.has(id));
      const get=id=>!isMapped(id)?'':row[mapping[id]];
      const idPF=category(get('id')),matricula=category(get('matricula'));
      const sourceId=str(origin.sourceId)||'fonte-1',sourceFile=str(origin.sourceFile),sourceSheet=str(origin.sourceSheet),sourceRow=Number.isInteger(Number(origin.sourceRow))&&Number(origin.sourceRow)>0?Number(origin.sourceRow):i+firstDataRow;
      const ageReference=date(origin.snapshotDate)||ref,snapshotDate=ageReference.toISOString().slice(0,10);
      const baseRecordId=JSON.stringify([sourceId,sourceSheet,sourceRow,snapshotDate]);let recordId=baseRecordId;if(recordIds.has(recordId))recordId=JSON.stringify([sourceId,sourceSheet,sourceRow,snapshotDate,i]);recordIds.add(recordId);
      const key=idPF?'PF:'+idPF:matricula?'MP:'+matricula:'';const person=key||`SEM_CHAVE_${recordId}`;
      if(key)people.add(person);
      const birth=isMissingDate(get('nascimento'))?null:date(get('nascimento'));const provided=isMissing(get('idade'))?null:Number(get('idade'));const calculated=ageAt(birth,ageReference);const age=calculated!=null?calculated:Number.isFinite(provided)&&provided>=0&&provided<=120?provided:null;
      const rec={index:i,rowNumber:sourceRow,recordId,sourceId,sourceFile,sourceSheet,sourceRow,snapshotDate,mappingSignature:str(origin.mappingSignature),ageReferenceDate:snapshotDate,person,key,matricula,nome:category(get('nome')),plano:category(get('plano'))||'Não informado',situacao:category(get('situacao'))||'Não informado',patrocinador:category(get('patrocinador'))||'Não informado',beneficio:category(get('beneficio'))||'Não informado',sexo:category(get('sexo'))||'Não informado',age,ageBand:ageBand(age),ageSource:calculated!=null?'Nascimento':age!=null?'Idade informada':'Não disponível',obito:!isMissingDate(get('obito')),channels:[],issues:[],status:'Consistente',errors:0,warnings:0,treatmentStatus:'Sem pendência',treatedAt:''};
      Object.assign(rec,classifyContract(rec.situacao,rec.beneficio));
      function add(rule,field,message,suggestion='',raw='',details={}){if(selected.has(rule)){const d=definitions[rule];rec.issues.push({rule,ruleLabel:d.label,severity:d.severity,field,message,suggestion,raw,...issueDetails(rule,details)});}}
      for(const ch of S.channels){const c=checkChannel(ch,get(ch.id),get(ch.ddd),isMapped(ch.id),isMapped(ch.ddd));rec.channels.push(c);c.findings.forEach(f=>{const {rule,message,suggestion,...details}=f;add(rule,ch.label,message,suggestion,c.raw,details);});if(c.present&&c.normalized){const k=(c.type==='email'?'email:':'fone:')+(c.ddd||'')+(c.type==='email'?c.normalized.toLowerCase():c.normalized),ownerKey=snapshotDate+'|'+k;if(!owners.has(ownerKey))owners.set(ownerKey,{first:person,shared:false});else if(owners.get(ownerKey).first!==person)owners.get(ownerKey).shared=true;c.contactKey=k;c.contactOwnerKey=ownerKey;}}
      const repeats=new Set();for(const c of rec.channels){if(!c.present||!c.contactKey)continue;if(repeats.has(c.contactKey))add('repeat',c.label,'Contato repetido em outro campo deste registro.','',c.raw);repeats.add(c.contactKey);}
      rec.mappedChannels=rec.channels.filter(c=>c.valid!==null).length;rec.mappedChannelsCount=rec.mappedChannels;rec.validChannels=rec.channels.filter(c=>c.valid===true).length;rec.presentChannels=rec.channels.filter(c=>c.present).length;rec.coverage=rec.mappedChannels?rec.validChannels>0?'Com canal válido':'Sem canal válido':'Não avaliado';
      if(rec.mappedChannels&&rec.validChannels===0)add('no_contact','Cobertura','Nenhum canal mapeado atende ao padrão técnico.');
      if(!key)add('identity','Identificação','Sem Id PF e sem Matrícula Petros; não é possível conciliar a pessoa.','','',{problem:'chave_pessoa_ausente'});
      const identity=person+'|'+JSON.stringify([snapshotDate,rec.plano,rec.situacao,rec.beneficio]);identities.set(identity,(identities.get(identity)||0)+1);rec.identity=identity;
      if(isMapped('nascimento')&&!isMissingDate(get('nascimento'))&&(!birth||birth>ageReference))add('age','Data Nascimento','Data de nascimento inválida ou posterior à data da fotografia.','',str(get('nascimento')));
      if(provided!=null&&(!Number.isFinite(provided)||provided<0||provided>120))add('age','Idade','Idade informada fora do intervalo 0–120.','',str(get('idade')));
      if(calculated!=null&&(calculated>120||provided!=null&&Number.isFinite(provided)&&Math.abs(calculated-provided)>1))add('age','Idade','Idade calculada diverge da informada ou excede 120 anos.','Confirmar referência e nascimento',str(get('idade')));
      if(rec.obito)add('death','Data Óbito',!date(get('obito'))||date(get('obito'))>ref?'Data de óbito inválida ou futura.':'Óbito informado: revisar elegibilidade do público de comunicação.','',str(get('obito')));
      records.push(rec);
      if(i%1500===0){onProgress?.({percent:Math.round(i/rows.length*80),phase:'Validando estrutura e contexto'});await new Promise(r=>setTimeout(r,0));}
    }
    for(let i=0;i<records.length;i++){const r=records[i];if(selected.has('shared'))for(const c of r.channels)if(c.contactOwnerKey&&owners.get(c.contactOwnerKey)?.shared)r.issues.push({rule:'shared',ruleLabel:definitions.shared.label,severity:'Alerta',field:c.label,message:'Contato associado a pessoas distintas na mesma fotografia; confirmar compartilhamento legítimo.',suggestion:'',raw:c.raw,...issueDetails('shared')});if(selected.has('identity')&&identities.get(r.identity)>1)r.issues.push({rule:'identity',ruleLabel:definitions.identity.label,severity:'Alerta',field:'Vínculo',message:'Combinação pessoa, plano, situação e benefício repetida na mesma fotografia.',suggestion:'',raw:'',...issueDetails('identity',{problem:'vinculo_repetido'})});r.errors=r.issues.filter(f=>f.severity==='Erro').length;r.warnings=r.issues.length-r.errors;r.status=r.errors?'Inconsistente':r.warnings?'Com ressalvas':selected.size?'Consistente':'Não avaliado';r.treatmentStatus=r.issues.length?'Pendente':'Sem pendência';if(i%3000===0){if(cancelled?.())throw new Error('Processamento cancelado.');onProgress?.({percent:80+Math.round(i/records.length*20),phase:'Conciliando contatos compartilhados'});await new Promise(r=>setTimeout(r,0));}}
    return {records,summary:summarize(records),people:people.size,ignored,mappedChannels,referenceDate:ref.toISOString().slice(0,10),selection:[...selected],version:S.version,runId:globalThis.crypto?.randomUUID?.()||`exec-${Date.now()}-${Math.random().toString(36).slice(2)}`,processedAt:new Date().toISOString()};
  }
  function summarize(records){const total=records.length;return {total,pass:records.filter(r=>r.status==='Consistente').length,warn:records.filter(r=>r.status==='Com ressalvas').length,fail:records.filter(r=>r.status==='Inconsistente').length,unassessed:records.filter(r=>r.status==='Não avaliado').length,covered:records.filter(r=>r.coverage==='Com canal válido').length,uncovered:records.filter(r=>r.coverage==='Sem canal válido').length,issues:records.reduce((n,r)=>n+r.issues.length,0),pending:records.filter(r=>r.issues.length&&r.treatmentStatus!=='Tratado').length,treated:records.filter(r=>r.issues.length&&r.treatmentStatus==='Tratado').length,pendingIssues:records.reduce((n,r)=>n+(r.treatmentStatus==='Tratado'?0:r.issues.length),0)};}
  function group(records,dimension){const groups=new Map();for(const r of records){const k=String(r[dimension]??'Não disponível');if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);}return [...groups].map(([label,rows])=>({label,...summarize(rows),people:new Set(rows.filter(r=>r.key).map(r=>r.person)).size})).sort((a,b)=>b.total-a.total||a.label.localeCompare(b.label));}
  return {str,norm,digits,isMissing,isMissingDate,date,ageAt,ageBand,autoMap,classifyContract,emailSyntaxProblem,checkChannel,process,summarize,group};
});
