(function(root,factory){
  const node=typeof module==='object'&&module.exports;
  const api=factory(root,node?require('./export.js'):root.ComV2Export,node?require('./xlsx-writer.js'):root.ComExport);
  if(node)module.exports=api;else root.ComMonthlyExport=api;
})(globalThis,function(root,E,W){
  'use strict';
  const enc=new TextEncoder(),mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  const escape=v=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  // Keep each sheet compressed, instead of retaining a whole workbook's XML in memory.
  // Input entries come only from our bundled JSZip writer, not from user uploads.
  class ZipAssembler{
    constructor(){this.body=[];this.central=[];this.offset=0;}
    add(bytes,source,target=source){
      const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),end=bytes.length-22;
      if(end<0||v.getUint32(end,true)!==0x06054b50)throw new Error('Pacote Excel intermediário inválido.');
      let p=v.getUint32(end+16,true);const n=v.getUint16(end+10,true);let found=false;
      for(let i=0;i<n;i++){
        if(v.getUint32(p,true)!==0x02014b50)throw new Error('Diretório Excel inválido.');
        const nl=v.getUint16(p+28,true),el=v.getUint16(p+30,true),cl=v.getUint16(p+32,true),name=new TextDecoder().decode(bytes.subarray(p+46,p+46+nl));
        if(name===source){
          const compressed=v.getUint32(p+20,true),plain=v.getUint32(p+24,true),local=v.getUint32(p+42,true),flags=v.getUint16(p+8,true),method=v.getUint16(p+10,true);
          if(flags&1||![0,8].includes(method)||compressed===0xffffffff||plain===0xffffffff||local===0xffffffff)throw new Error('Formato Excel intermediário não suportado.');
          if(v.getUint32(local,true)!==0x04034b50)throw new Error('Entrada Excel inválida.');
          const start=local+30+v.getUint16(local+26,true)+v.getUint16(local+28,true),nameBytes=enc.encode(target);
          if(start+compressed>bytes.length||this.offset+30+nameBytes.length+compressed>0xffffffff)throw new Error('Arquivo mensal ultrapassa 4 GB. Use a extração em blocos.');
          const header=Uint8Array.from(bytes.subarray(local,local+30)),hv=new DataView(header.buffer);hv.setUint16(6,(flags&~8)|0x800,true);hv.setUint32(14,v.getUint32(p+16,true),true);hv.setUint32(18,compressed,true);hv.setUint32(22,plain,true);hv.setUint16(26,nameBytes.length,true);hv.setUint16(28,0,true);
          const central=Uint8Array.from(bytes.subarray(p,p+46)),cv=new DataView(central.buffer);cv.setUint16(8,(flags&~8)|0x800,true);cv.setUint16(28,nameBytes.length,true);cv.setUint16(30,0,true);cv.setUint16(32,0,true);cv.setUint16(34,0,true);cv.setUint32(42,this.offset,true);
          this.body.push(header,nameBytes,bytes.subarray(start,start+compressed));this.central.push(central,nameBytes);this.offset+=header.length+nameBytes.length+compressed;found=true;break;
        }
        p+=46+nl+el+cl;
      }
      if(!found)throw new Error('Parte Excel ausente: '+source);
    }
    finish(){
      const count=this.central.length/2,centralSize=this.central.reduce((n,p)=>n+p.length,0);
      if(count>65535||this.offset+centralSize+22>0xffffffff)throw new Error('Arquivo mensal muito grande. Use a extração em blocos.');
      const end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,count,true);v.setUint16(10,count,true);v.setUint32(12,centralSize,true);v.setUint32(16,this.offset,true);
      return new Blob([...this.body,...this.central,end],{type:mime});
    }
  }
  function check(state){
    const r=state?.result;if(!r)throw new Error('Conclua as duas etapas antes de gerar o arquivo mensal.');
    if(r.photos.length!==1)throw new Error('O arquivo mensal requer uma única fotografia. Processe cada fotografia separadamente.');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(r.photos[0]))throw new Error('Fotografia inválida.');
    return r.photos[0];
  }
  async function generate(state,onProgress,{chunkRows=25000}={}){
    const date=check(state),month=date.slice(0,7),data=E.tables(state,'bi'),meta=data.Execucao;
    data.Execucao=[
      [...meta[0],'Contrato_PBI_Mensal','Data_Fotografia','Competencia'],
      [...meta[1],1,new Date(date+'T00:00:00Z'),month]
    ];
    if(!Number.isInteger(chunkRows)||chunkRows<1||chunkRows>50000)throw new Error('Tamanho de bloco inválido.');
    const out=new ZipAssembler(),sheets=[];let styles=false;
    for(const [table,iterable] of Object.entries(data)){
      const iterator=iterable[Symbol.iterator](),header=iterator.next().value;let next=iterator.next(),part=1;
      do{
        const rows=[header];while(!next.done&&rows.length<=chunkRows){rows.push(next.value);next=iterator.next();}
        const name=(table+(part>1?'_'+part:'')).slice(0,31),id=sheets.length+1;
        const blob=await W.workbook({[name]:rows},p=>onProgress?.({...p,phase:`Arquivo mensal · ${name}`,detail:p.phase}));
        const bytes=new Uint8Array(await blob.arrayBuffer());
        out.add(bytes,'xl/worksheets/sheet1.xml',`xl/worksheets/sheet${id}.xml`);
        if(!styles){out.add(bytes,'xl/styles.xml');styles=true;}
        sheets.push({id,name,table,rows:rows.length-1});part++;
        await new Promise(resolve=>setTimeout(resolve,0));
      }while(!next.done);
    }
    const zip=new root.JSZip();
    zip.file('[Content_Types].xml',`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map(s=>`<Override PartName="/xl/worksheets/sheet${s.id}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`,{createFolders:false});
    zip.file('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',{createFolders:false});
    zip.file('xl/workbook.xml',`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map(s=>`<sheet name="${escape(s.name)}" sheetId="${s.id}" r:id="rId${s.id}"/>`).join('')}</sheets></workbook>`,{createFolders:false});
    zip.file('xl/_rels/workbook.xml.rels',`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map(s=>`<Relationship Id="rId${s.id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${s.id}.xml"/>`).join('')}<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,{createFolders:false});
    const metaBytes=await zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
    for(const path of Object.keys(zip.files))out.add(metaBytes,path);
    onProgress?.({percent:100,phase:'Arquivo mensal concluído',detail:month+' · '+sheets.length+' abas, sem truncamento'});
    return {blob:out.finish(),filename:`PETROS_PBI_MENSAL_${month}.xlsx`,month,date,sheets};
  }
  return {generate,check,ZipAssembler};
});
