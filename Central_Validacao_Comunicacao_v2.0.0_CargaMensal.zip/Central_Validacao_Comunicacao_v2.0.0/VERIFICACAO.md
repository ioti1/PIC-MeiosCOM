# Verificação da versão 2.0.0

## Complemento de 16/10/2026 - arquivo mensal único

Foi acrescentado o botão Gerar arquivo mensal PBI (.xlsx), sem remover ou alterar o contrato das exportações anteriores. Gera um XLSX completo de uma fotografia, com nome estável por competência e metadados de contrato mensal. Filtros da fila/painel não reduzem esta extração.

`tests/monthly-export.cjs`: seis casos de bloqueio, todas as partes no mesmo XLSX, integridade CRC, metadados, novo mês/reprocessamento e recusa de múltiplas fotografias. O teste de interação ganhou o caso do botão mensal (25 casos ao todo). `tests/monthly-contract.cjs` verifica nomes de medidas/colunas e cenários de referência de virada de ano, lacuna mensal e mudança de regras; é revisão estática/referencial, não execução do Power Query ou DAX.

O teste completo com as bases fornecidas gerou em memória um único XLSX de aproximadamente 157 MB, com 42 abas. A abertura ZIP/CRC e as linhas foram reconciliadas: 123.845 participantes, 128.434 vínculos, 479.629 contatos, 118.888 achados, 2.144 indicadores e 34.557 grupos por usuário/dia, além de execução/fontes/regras. A geração e conferência levaram aproximadamente 115 segundos no ambiente de teste. O calendário usado no teste é entrada de QA, não uma declaração da fotografia real de negócio.

Um arquivo sintético com múltiplas abas também foi aberto por openpyxl, independentemente do leitor da aplicação, confirmando todos os 16 contatos. Nenhum arquivo real foi colocado no pacote de distribuição.

As consultas e medidas de PowerBI_Mensal não foram executadas no Power BI Desktop nesta entrega. O manual distingue configuração inicial, homologação e rotina mensal. A publicação/atualização agendada exige infraestrutura e autorização próprias; não é ativada pelo HTML.

Verificação funcional executada em 15/10/2026. As datas de fotografia usadas nos testes são entradas de QA, não uma afirmação sobre a data real das bases enviadas.

## Testes automatizados

- `tests/core-v2.cjs`: 20 verificações do novo modelo, incluindo duas etapas, 5 telefones + 5 celulares + 6 e-mails, universo oficial, ausência/invalidade, cadastro, tratamento e releitura de Excel.
- `tests/ui-v2.cjs`: 24 verificações de interação em ambiente de DOM simulado, incluindo fotografia histórica manual, bloqueios, filtros de regras, datas/demografia, paginação, evidências, proteção de HTML, andamento, PDF e exportação.
- `tests/core-validators.cjs`: 22 regressões das regras existentes de comunicação, DDD com zeros, mensagens específicas, grupos e idade por fotografia.
- `tests/reader-v2.cjs`: 4 verificações de leitura XML, garantindo que células/linhas vazias autocontidas não absorvam o próximo valor, não recebam o primeiro texto compartilhado e não convertam silenciosamente datas do calendário 1904.
- `tests/export-volume.cjs`: 4 verificações de blocos com 25.007 contatos, escopo filtrado, valores que parecem fórmulas preservados como texto e formato de data/hora de cadastro à meia-noite.

Total: **74 verificações funcionais**, além das verificações estáticas e dos testes com as bases completas.

## Bases completas e extração integral

A leitura/validação da base oficial e da base de contatos fornecidas foi executada diretamente pelos módulos utilizados na aplicação. Uma segunda leitura independente com openpyxl reconciliou o universo, os vínculos, os tipos de contato, os matches, os externos e as classificações de ausência.

Contagens reconciliadas: 128.434 vínculos oficiais, 123.845 participantes identificados, 479.629 linhas de contato, 420.950 contatos vinculados e 58.679 externos. Foram preservados até 24 contatos de um participante. Há 124 participantes sem registro de comunicação e 933 sem e-mail cadastrado nesse cruzamento de QA. Esses números não constituem relatório homologado de uma fotografia de negócio.

A extração integral foi gerada **em memória**, aberta novamente e contada por tabela: 123.845 linhas de participantes; 128.434 vínculos; 479.629 contatos; 118.888 achados; 2.144 indicadores e 34.557 grupos usuário/dia. O ZIP resultante tinha 40 arquivos XLSX, aproximadamente 157 MB. As quatro tabelas de detalhe foram reconciliadas com o resultado do motor. Nenhuma base real nem essa extração foi incorporada ao pacote da aplicação.

A validação do motor levou aproximadamente 17 segundos após a leitura; geração e conferência da extração levaram aproximadamente 104 segundos neste ambiente Node local. Isso não mede a velocidade de um navegador nem estabelece SLA. O teste utilizou cerca de 2 GB de memória no estágio de validação; é importante usar navegador de 64 bits e memória disponível.

Datas de cadastro preenchidas e interpretáveis são medidas diferentes. Valores inválidos ou incompatíveis com o padrão brasileiro ficam com o original preservado e geram apontamento de data quando a regra está selecionada, em vez de receberem uma conversão silenciosa.

## Limites e homologação

Não foi possível inspecionar esta versão num navegador durante a execução. Os testes de interação são simulados e não substituem inspeção visual. O CSS de impressão e o conteúdo do relatório foram revisados, mas a paginação final do PDF, diferenças de impressora e responsividade visual **não estão homologadas por captura de tela**.

Antes de uso oficial, abra a demonstração, revise a visualização em sua resolução e faça uma impressão de teste. Em seguida, execute as bases com a fotografia real informada pelo operador, confira uma amostra das evidências e homologue as regras com a área responsável.

Os testes não verificam existência de caixas de e-mail, atividade de linhas, titularidade ou legitimidade de compartilhamentos. A aplicação é de pré-validação estrutural e conciliação, não substitui confirmação com o participante.
