let
    Inicio = List.Min(ArquivosPBI[Mes_Referencia]),
    Fim = List.Max(ArquivosPBI[Mes_Referencia]),
    Meses = List.Generate(()=>Inicio,each _ <= Fim,each Date.AddMonths(_,1)),
    Base = Table.FromList(Meses,Splitter.SplitByNothing(),{"Mes_Referencia"}),
    ComTipos = Table.TransformColumnTypes(Base,{{"Mes_Referencia",type date}}),
    Juncao = Table.NestedJoin(ComTipos,{"Mes_Referencia"},
        ArquivosPBI,{"Mes_Referencia"},"Fonte",JoinKind.LeftOuter),
    Expandida = Table.ExpandTableColumn(Juncao,"Fonte",
        {"Fotografia","Id_Execucao","Perfil_Regras","Nome"},
        {"Data_Fotografia","Id_Execucao","Perfil_Regras","Arquivo_PBI"}),
    ComAnoMes = Table.AddColumn(Expandida,"AnoMes",
        each Date.ToText([Mes_Referencia],"yyyy-MM","en-US"),type text),
    ComStatus = Table.AddColumn(ComAnoMes,"Status_Mes",each
        if [Data_Fotografia] = null then "Sem arquivo" else "Recebido",type text),
    Resultado = Table.TransformColumnTypes(ComStatus,
        {{"Data_Fotografia",type date}})
in Resultado
