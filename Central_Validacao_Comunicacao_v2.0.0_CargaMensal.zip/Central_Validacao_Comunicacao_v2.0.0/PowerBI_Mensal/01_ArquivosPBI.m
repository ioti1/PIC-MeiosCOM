let
    Fonte = Folder.Contents(pPastaPBI),
    Excel = Table.SelectRows(Fonte, each
        [Extension] <> null and Text.Lower([Extension]) = ".xlsx"
        and not Text.StartsWith([Name], "~$")),
    Estranhos = Table.SelectRows(Excel,each not
        Text.StartsWith(Text.Upper([Name]), "PETROS_PBI_MENSAL_")),
    OutrosFormatos = Table.SelectRows(Fonte,each [Extension] <> null and
        List.Contains({".zip",".xls",".csv"},Text.Lower([Extension]))),
    Candidatos = if Table.RowCount(Estranhos) > 0 or
        Table.RowCount(OutrosFormatos) > 0 then error
        "Entrada deve conter só os arquivos mensais PBI. Retire ZIP, exportações antigas e recortes."
        else Excel,
    Ler = (Linha as record) as record =>
        let
            Nome = Linha[Name],
            MesNome = try Date.FromText(Text.Middle(Nome,18,7) & "-01",
                [Format="yyyy-MM-dd", Culture="en-US"]) otherwise null,
            Padrao = if MesNome = null then false else
                Text.Upper(Nome) = ("PETROS_PBI_MENSAL_" &
                    Date.ToText(MesNome,"yyyy-MM","en-US") & ".XLSX"),
            Livro = if not Padrao then error
                ("Nome fora do padrão mensal: " & Nome &
                ". Remova cópias (1) e mantenha só o arquivo oficial do mês.")
                else Excel.Workbook(Linha[Content], null, true),
            Aba = try Livro{[Item="Execucao",Kind="Sheet"]}[Data]
                otherwise error ("Falta a aba Execucao em " & Nome),
            Exec = Table.PromoteHeaders(Aba,
                [PromoteAllScalars=true, Culture="pt-BR"]),
            Registro = if Table.RowCount(Exec) = 1 then Exec{0}
                else error ("Execucao deve conter uma linha: " & Nome),
            Foto = try Date.From(Registro[Data_Fotografia]) otherwise null,
            Valido = if Foto = null then false else
                Record.FieldOrDefault(Registro,"Contrato_PBI_Mensal",0) = 1
                and Record.FieldOrDefault(Registro,"Universo_Oficial_Completo",0) = 1
                and Date.StartOfMonth(Foto) = MesNome
                and Registro[Fotografias] = Date.ToText(Foto,"yyyy-MM-dd","en-US")
                and Registro[Competencia] = Date.ToText(MesNome,"yyyy-MM","en-US"),
            Resultado = if not Valido then error
                ("Arquivo mensal inválido ou recorte parcial: " & Nome &
                ". Gere novamente pelo botão Gerar arquivo mensal PBI do HUB.")
                else [Nome=Nome, Fotografia=Foto, Mes_Referencia=MesNome,
                    Id_Execucao=Text.From(Registro[Id_Execucao]),
                    Perfil_Regras=Text.From(Registro[Versao]) & "|" &
                        Text.From(Registro[Regras]), Livro=Livro]
        in Resultado,
    Registros = List.Transform(Table.ToRecords(Candidatos), each Ler(_)),
    Dados = if List.IsEmpty(Registros) then error
        "Nenhum arquivo mensal encontrado. Gere no HUB e copie para a pasta Entrada."
        else Table.FromRecords(Registros),
    Contagem = Table.Group(Dados,{"Mes_Referencia"},
        {{"Quantidade",each Table.RowCount(_),Int64.Type}}),
    Duplicados = Table.SelectRows(Contagem,each [Quantidade] <> 1)
in
    if Table.RowCount(Duplicados) > 0 then error
        "Há mais de um arquivo para o mesmo mês. Mantenha uma execução oficial por mês."
    else Dados
