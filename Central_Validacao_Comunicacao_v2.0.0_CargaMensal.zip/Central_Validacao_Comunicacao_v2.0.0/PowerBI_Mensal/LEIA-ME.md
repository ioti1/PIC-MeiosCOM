# Carga mensal - uma configuração, uma pasta

O PDF revisado é o passo a passo principal. Este pacote não é um PBIX pronto. A montagem inicial das consultas, relações e medidas precisa ser feita uma vez no Power BI Desktop.

## Todo mês, depois de configurado

1. Informe a fotografia e processe as duas bases no HUB.
2. Use **Gerar arquivo mensal PBI (.xlsx)**.
3. Copie `PETROS_PBI_MENSAL_AAAA-MM.xlsx` diretamente para sua pasta **Entrada**.
4. Abra o PBIX e clique **Atualizar**. Não reconstrua tabelas ou gráficos.

Mês novo acrescenta um arquivo. Reprocessamento substitui somente o mesmo mês, com o mesmo nome. Preserve os demais arquivos para manter o histórico. Guarde versões antigas fora de Entrada. Não deixe cópias com `(1)` no nome. Não use a exportação antiga em ZIP ou um recorte da fila neste conector.

## Configuração inicial

Crie cada consulta em branco, abra Editor avançado e cole o conteúdo do respectivo arquivo:

| Arquivo | Nome exato da consulta |
| --- | --- |
| 00_pPastaPBI.m | pPastaPBI |
| 01_ArquivosPBI.m | ArquivosPBI |
| 02_fnTabelaPBI.m | fnTabelaPBI |
| 03_Fotografias.m | Fotografias |

Altere apenas o caminho de pPastaPBI para a pasta autorizada. Desative Habilitar carregamento de ArquivosPBI e do apoio pPastaPBI quando disponível. Mantenha-as como consultas de apoio.

Crie as consultas de dados com uma expressão por consulta:

```
Participantes       -> fnTabelaPBI("Participantes")
Vinculos_Oficiais   -> fnTabelaPBI("Vinculos_Oficiais")
Contatos            -> fnTabelaPBI("Contatos")
Achados             -> fnTabelaPBI("Achados")
Execucao            -> fnTabelaPBI("Execucao")
Indicadores         -> fnTabelaPBI("Indicadores")
```

O nome à esquerda é dado à consulta; somente a expressão à direita vai no Editor avançado. A função lê todas as abas/partes de cada tabela em todos os arquivos mensais.

Siga o PDF para criar ChaveParticipante e ChaveContato. Relacione Fotografias[Mes_Referencia] (1) a Participantes[Mes_Referencia] (*), filtro único. Participantes se liga aos vínculos, contatos e achados por ChaveParticipante. Não crie caminhos redundantes.

Crie uma medida por vez com `04_Medidas_Mensais.dax`. As medidas de estoque usam o último mês disponível quando o filtro de mês está limpo. Cada ponto da série usa o próprio mês. Salve o relatório com AnoMes sem seleção fixa. Se pesquisar o passado, limpe a seleção para voltar ao modo mais recente.

O mês anterior é o mês de calendário imediatamente anterior, não o último arquivo encontrado. Se faltar arquivo, mudar o perfil de regras/versão ou não houver denominador, o comparativo fica vazio. A variação de taxas é em pontos percentuais.

## Validações

O conector verifica nome do arquivo, competência, fotografia, contrato mensal e universo completo. Valida colunas e identificadores das linhas e identifica meses intermediários sem arquivo. Não escolha arquivos pela data de modificação do Windows.

A exportação foi conferida com as bases completas. As receitas M/DAX foram revisadas contra o contrato, mas não executadas no Power BI Desktop nesta entrega; a configuração inicial requer homologação local. As regras idênticas não garantem, sozinhas, populações comparáveis.

O histórico é relido durante a atualização. Não é uma carga incremental de servidor. Com o crescimento do volume, o tempo/memória aumentam. Atualização agendada no serviço e acesso de gestão dependem de infraestrutura, licença e aprovação da TI. Não use Publicar na Web para dados cadastrais.
