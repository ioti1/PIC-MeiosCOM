(Tabela as text) as table =>
let
    Partes = List.Transform(Table.ToRecords(ArquivosPBI), (Arq as record) =>
        let
            Abas = Table.SelectRows(Arq[Livro], each [Kind] = "Sheet" and
                ([Item] = Tabela or (Text.StartsWith([Item],Tabela & "_") and
                (try Number.FromText(Text.AfterDelimiter([Item],Tabela & "_"))
                    > 1 otherwise false)))),
            Promovidas = if Table.RowCount(Abas) = 0 then error
                ("Tabela " & Tabela & " ausente em " & Arq[Nome]) else
                List.Transform(Abas[Data], each Table.PromoteHeaders(_,
                    [PromoteAllScalars=true,Culture="pt-BR"])),
            Esquemas = List.Transform(Promovidas,each List.Sort(Table.ColumnNames(_))),
            Iguais = List.AllTrue(List.Transform(Esquemas,each _ = Esquemas{0})),
            Uniao = if Iguais then Table.Combine(Promovidas) else error
                ("Abas com colunas diferentes em " & Arq[Nome]),
            Exigidas = if Table.HasColumns(Uniao,{"Id_Execucao","Data_Fotografia"})
                then Uniao else error ("Colunas obrigatórias ausentes em " & Arq[Nome]),
            TiposBase = {{"Id_Execucao",type text},{"Id_Participante",type text},
                {"Id_Contato",type text},{"Matricula_Petros",type text},
                {"Data_Fotografia",type date},{"Data_Cadastro",type datetime}},
            SemVazios = if Table.HasColumns(Exigidas,"Data_Cadastro") then
                Table.TransformColumns(Exigidas,{{"Data_Cadastro",each
                    if _ = null or (Value.Is(_,type text) and Text.Trim(_) = "")
                    then null else _,type any}}) else Exigidas,
            Tipos = Table.TransformColumnTypes(SemVazios,
                List.Select(TiposBase,each List.Contains(Table.ColumnNames(Exigidas),_{0})),
                "pt-BR"),
            Divergentes = Table.SelectRows(Tipos,each
                [Id_Execucao] <> Arq[Id_Execucao] or
                [Data_Fotografia] <> Arq[Fotografia]),
            Conferida = if Table.RowCount(Divergentes) > 0 then error
                ("Linhas de outra execução ou fotografia em " & Arq[Nome]) else Tipos,
            ComArquivo = Table.AddColumn(Conferida,"Arquivo_PBI",each Arq[Nome],type text),
            ComMes = Table.AddColumn(ComArquivo,"Mes_Referencia",
                each Arq[Mes_Referencia],type date)
        in ComMes),
    Colunas = List.Transform(Partes,each List.Sort(Table.ColumnNames(_))),
    MesmoEsquema = List.AllTrue(List.Transform(Colunas,each _ = Colunas{0}))
in
    if MesmoEsquema then Table.Combine(Partes) else error
        ("O formato de " & Tabela & " mudou entre meses. Revise a carga antes de comparar.")
