// Functional checks in a DOM stand-in. These do not verify browser layout.
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
class Element{
  constructor(id,value=''){this.id=id;this.value=value;this.hidden=false;this.disabled=false;this.open=false;this.dataset={};this.listeners={};this.classes=new Set();this.classList={toggle:(c,force)=>{if(force===undefined)force=!this.classes.has(c);force?this.classes.add(c):this.classes.delete(c);},add:c=>this.classes.add(c),remove:c=>this.classes.delete(c)};}
  set innerHTML(v){this.markup=v;if(this.id==='sheetSelect'){const m=v.match(/<option[^>]*>([^<]*)<\/option>/);if(m)this.value=m[1];}}
  get innerHTML(){return this.markup||'';}
  addEventListener(type,fn){(this.listeners[type]||=[]).push(fn);}
  async fire(type,event={}){for(const fn of this.listeners[type]||[])await fn({target:this,preventDefault(){},...event});}
  showModal(){this.open=true;}close(){this.open=false;}
}
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element(m[1])]));
elements.headerRow.value='1';elements.dimension.value='plano';elements.pageSize.value='20';
const viewButtons=['source','rules','dashboard','records','exports'].map(v=>{const e=new Element('nav-'+v);e.dataset.view=v;return e;});
const selectButtons=['all','none'].map(v=>{const e=new Element('select-'+v);e.dataset.select=v;return e;});
const filterElements=['plano','situacao','ageBand','patrocinador','obito'].map(v=>{const e=new Element(v);e.dataset.filter=v;return e;});
const brand=new Element('brand'),body=new Element('body');
const document={body,querySelector(selector){if(selector.startsWith('#')){const e=elements[selector.slice(1)];assert.ok(e,'Missing element '+selector);return e;}if(selector==='.brand')return brand;const f=selector.match(/^\[data-filter="([^"]+)"\]$/);if(f)return filterElements.find(e=>e.dataset.filter===f[1]);throw new Error('Unmodeled selector '+selector);},querySelectorAll(selector){if(selector==='.view')return Object.values(elements).filter(e=>e.id.startsWith('view-'));if(selector==='[data-view]'||selector==='nav [data-view]')return viewButtons;if(selector==='[data-select]')return selectButtons;if(selector==='[data-filter]')return filterElements;throw new Error('Unmodeled selector '+selector);}};
const context=vm.createContext({document,console,Blob,URL,crypto:require('node:crypto').webcrypto,Date,setTimeout,clearTimeout,performance,window:{scrollTo(){},print(){}}});
for(const file of ['utils.js','schema.js','audit.js','export.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,'src',file),'utf8'),context,{filename:file});
context.JSZip=require('../vendor/jszip.min.js');let download;context.CVCUtils.downloadBlob=(blob,name)=>download={blob,name};
(async()=>{
  const app=context.ComApp;app.loadDemo();assert.equal(app.state.rows.length,137);assert.equal(Object.keys(app.state.mapping).length,23);assert.ok(elements.mappingBody.innerHTML.includes('DDD Celular 1'));console.log('✓ Demonstração e mapeamento das 23 colunas');
  elements.referenceDate.value='2026-10-06';await app.run();assert.equal(app.state.result.summary.total,137);assert.equal(elements.progressDialog.open,false);assert.ok(elements.kpis.innerHTML.includes('Participantes únicos'));console.log('✓ Fluxo completo de processamento atualiza painel e fecha progresso');
  await viewButtons.find(b=>b.dataset.view==='records').fire('click');assert.equal((elements.recordsBody.innerHTML.match(/<tr>/g)||[]).length,20);const first=elements.recordsBody.innerHTML;await elements.nextPage.fire('click');assert.equal(app.state.page,2);assert.notEqual(elements.recordsBody.innerHTML,first);console.log('✓ Paginação muda efetivamente os registros exibidos');
  elements.pageSize.value='100';await elements.pageSize.fire('change');assert.equal((elements.recordsBody.innerHTML.match(/<tr>/g)||[]).length,100);elements.pageSize.value='all';await elements.pageSize.fire('change');assert.equal((elements.recordsBody.innerHTML.match(/<tr>/g)||[]).length,137);console.log('✓ Opções 100 e Todos usam todo o universo solicitado');
  elements.statusFilter.value='Inconsistente';await elements.statusFilter.fire('change');assert.equal(app.filteredRecords().length,app.state.result.summary.fail);console.log('✓ Filtros da fila conciliam com resultado do processamento');
  const plan=filterElements.find(e=>e.dataset.filter==='plano');plan.value='Plano A';await elements.dashFilters.fire('change',{target:plan});assert.ok(elements.scopeNote.textContent.includes('recorte'));console.log('✓ Filtro gerencial atualiza escopo e indicadores');
  app.state.result.records[0].nome='<img src=x onerror=alert(1)>';elements.search.value='';elements.statusFilter.value='';await elements.statusFilter.fire('change');assert.ok(elements.recordsBody.innerHTML.includes('&lt;img'));assert.ok(!elements.recordsBody.innerHTML.includes('<img src=x'));console.log('✓ Valores importados são escapados na tela');
  await app.exportFile('bi');assert.ok(download.name.includes('POWERBI'));assert.ok(download.blob.size>5000);assert.equal(elements.progressDialog.open,false);console.log('✓ Exportação gerencial conclui e produz XLSX');
  await selectButtons.find(b=>b.dataset.select==='none').fire('click');assert.equal(app.state.selection.length,0);assert.equal(app.state.result,null);assert.equal(elements.biBtn.disabled,true);console.log('✓ Alterar escopo invalida resultado e impede exportação obsoleta');
  await selectButtons.find(b=>b.dataset.select==='all').fire('click');assert.equal(app.state.selection.length,17);console.log('✓ Selecionar todas restaura as regras');
  const groupButton={dataset:{group:'1',value:'none'}};await elements.ruleGroups.fire('click',{target:{closest:()=>groupButton}});assert.ok(!app.state.selection.includes('email_syntax'));assert.ok(app.state.selection.includes('ddd'));console.log('✓ Desmarcar grupo altera somente regras de e-mail');
  console.log('11 verificações de interação aprovadas (sem inspeção visual de navegador).');
})().catch(e=>{console.error(e);process.exitCode=1;});
