# Petros — Qualidade dos Meios de Comunicação

Aplicação local e offline para pré-validar DDDs, telefones fixos, celulares e e-mails. Abra `index.html` no Edge ou Chrome. O validador cadastral anterior foi preservado em sua pasta e no pacote v0.9.2.

## Uso

1. Importe XLSX, CSV ou TXT delimitado. Escolha aba, linha do cabeçalho e data de referência.
2. Revise o mapeamento. O nome do arquivo não determina o layout. O modelo de 23 campos segue a ordem da referência fornecida, incluindo DDDs repetidos para telefones e celulares.
3. Selecione regras, individualmente ou por grupo, e execute a pré-validação.
4. Explore plano, situação contratual, faixa etária, patrocinador, benefício e sexo. Os filtros gerenciais afetam apenas a tela e o relatório PDF. A fila possui filtros próprios e 20, 100 ou todos os registros por página.
5. Exporte o Excel de tratamento, o Excel para Power BI e, se necessário, o detalhe dos canais. Para salvar PDF, escolha “Salvar como PDF” na impressão do navegador.

## Definições de auditoria

- Registro: uma linha não vazia da base, conservando a linha física de origem. Não é necessariamente uma pessoa única.
- Pessoa única: Id PF, com Matrícula Petros como alternativa. As chaves recebem prefixos PF/MP para impedir colisões. Registros sem chave não entram no total de pessoas únicas. Pessoas únicas por plano não são aditivas.
- Consistente: sem achados nas regras selecionadas. Com ressalvas: alertas, sem erros. Inconsistente: ao menos um erro.
- Cobertura técnica: ao menos um canal mapeado com estrutura válida, calculada independentemente das regras selecionadas. Não confirma entrega, titularidade ou linha ativa. Sequências suspeitas, placeholders e erros possíveis de domínio geram alertas separados; não comprovam impossibilidade técnica de uso.
- Canal ausente: campo vazio ou marcador técnico de ausência (`-`, `--`, `NULL`, `(NULL)`, `N/A`, `NaN`, `None`). O hífen é o padrão de ausência observado na base fornecida. Esses valores são preservados na origem exportada, mas não geram falsos erros de sintaxe, repetição ou compartilhamento. Datas zeradas também representam ausência. Campos individuais são opcionais; a regra de ausência de canal válido avalia o conjunto mapeado. Canal não mapeado fica “Não avaliado”.
- Idade: calculada pelo nascimento na data de referência. Se indisponível, usa a idade informada entre 0 e 120. Divergência acima de um ano gera alerta quando a regra está selecionada.
- Contato compartilhado: contato normalizado associado a chaves de pessoas distintas; um alerta para confirmar compartilhamento legítimo. A mesma pessoa em dois planos não gera esse alerta.
- Óbito: informação é sinalizada para revisão do público quando a regra está selecionada. Nenhum registro é excluído automaticamente.

A sintaxe de e-mail cobre endereços usuais com caracteres ASCII e domínio com ponto. Endereços internacionalizados e sintaxes especiais com parte local entre aspas exigem revisão. A lista de possíveis erros de domínio é conservadora e configurada em `src/audit.js`; sugestões não são aplicadas automaticamente. Maiúsculas na parte local do e-mail são preservadas.

O escopo de telefonia é Brasil. São interpretadas máscaras, DDD incorporado, código do país 55 e DDD com zeros de preenchimento à esquerda (ex.: 0021 → 21). O preenchimento com zeros gera alerta de padronização, sem falso erro de DDD inexistente. Números de outros países, serviços especiais, ramais e múltiplos números num único campo exigem tratamento separado. DDD/UF indica área de numeração, não residência atual.

## Excel e Power BI

Tratamento: preserva a ordem dos campos originais e insere colunas coloridas de validação técnica, achados e sugestões após cada contato mapeado. Os valores originais não são substituídos. Datas de nascimento/óbito reconhecidas são gravadas como datas Excel com exibição DD/MM/AAAA. Campos manuais de ação, responsável, data e observação apoiam o saneamento.

Power BI: `Fato_Registros` tem uma linha por registro/execução. `Fato_Achados` tem uma linha por achado, campo e regra. `Indicadores` contém contagens por dimensão e categoria; não some linhas de dimensões diferentes. `Execucao` identifica referência, versão, arquivo e escopo. `Regras` registra a seleção. O arquivo de canais separado contém `Fato_Contatos`, com uma linha por canal mapeado e registro, inclusive ausências.

Exportações com mais de 25 mil linhas estimadas geram um ZIP com arquivos Excel separados por tabela e bloco, de até 25 mil linhas cada, sem truncamento. Cada arquivo repete o cabeçalho. Um arquivo Contexto contém execução, regras e indicadores, quando aplicável. Combine arquivos com o mesmo prefixo no Power Query, promovendo o cabeçalho antes de combinar. Exportações menores geram um único XLSX. A divisão reduz o consumo de memória e oferece blocos manejáveis para tratamento e Power BI.

Guarde cada Excel gerencial em uma pasta histórica. No Power BI, use “Obter dados > Pasta”, filtre os nomes das tabelas por prefixo e combine os arquivos. Crie a chave `Id_Execucao & "|" & Id_Registro` nos fatos para a relação 1:N de registros com achados e canais. Relacione `Execucao` por `Id_Execucao`. Não relacione apenas por pessoa: isso duplicaria vínculos e execuções.

Medidas sugeridas sobre Fato_Registros:

```dax
Registros = COUNTROWS(Fato_Registros)
Com erro = CALCULATE([Registros], Fato_Registros[Resultado] = "Inconsistente")
Taxa com erro = DIVIDE([Com erro], [Registros])
Com canal válido = CALCULATE([Registros], Fato_Registros[Cobertura] = "Com canal válido")
Cobertura técnica = DIVIDE([Com canal válido], [Registros])
Pessoas únicas = CALCULATE(DISTINCTCOUNT(Fato_Registros[Id_Pessoa]), Fato_Registros[Id_Pessoa] <> "")
```

Compare execuções com versão, canais mapeados e regras equivalentes. Evite importar a mesma execução duas vezes. Repetir um processamento cria uma nova execução: a data de referência e o ID precisam compor o filtro de acompanhamento. O arquivo de tratamento contém o resultado do processamento original; editar suas colunas manuais não recalcula o Excel gerencial. Reimporte a base corrigida para medir a evolução.

## Fontes técnicas

Tabela de DDDs e padrões consultados em 06/10/2026:

- Anatel — Plano de Numeração Brasileiro: https://www.gov.br/anatel/pt-br/regulado/numeracao/plano-de-numeracao-brasileiro
- Anatel — Perguntas frequentes de numeração: https://www.gov.br/anatel/pt-br/regulado/numeracao/perguntas-frequentes
- Anatel — Nono dígito: https://www.gov.br/anatel/pt-br/regulado/numeracao/codigos-nacionais/nono-digito

Regras internas de placeholders, compartilhamento, padronização e contexto são heurísticas de pré-validação, documentadas e configuráveis; não são prova de erro de titularidade.

## Privacidade e operação

Sem envio de dados, APIs, CDN ou telemetria. Bibliotecas, imagens e arquivos são locais. Bases e resultados ficam em memória e não são persistidos pelo aplicativo. A configuração pode ser salva em JSON sem registros pessoais. O nome do arquivo aparece apenas nos metadados de execução. O pacote de entrega contém somente demonstração fictícia, código e documentação.

XLS legado não é suportado. Fórmulas são lidas pelo valor armazenado; recalcule e salve a base antes de importar. Identificadores devem ser armazenados como texto para preservar zeros que já poderiam ter sido perdidos no arquivo de origem. Capacidade depende da memória disponível no navegador; exportações completas exigem mais memória que a visualização paginada.

## Evolução e testes

`src/schema.js` define campos, DDDs e regras; `src/audit.js` contém a avaliação; `src/export.js` contém tabelas e geração local de XLSX; `src/app.js` controla a interface. Execute `node tests/run-tests.cjs`, `node tests/ui-smoke.cjs` e `node tests/large-export.cjs`. Para validar uma base real sem exportar dados, acrescente seu caminho como argumento ao primeiro teste. A suíte de interação usa um ambiente DOM simulado: verifica fluxos e conteúdo, não o layout renderizado do navegador.

Versão 1.0.0. Identidade visual baseada no HUB fornecido: Segoe UI, azul profundo, azul-petróleo e superfícies claras, com logos do próprio HUB.
