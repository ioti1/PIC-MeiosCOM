# Validador cadastral preservado

O validador geral permanece na pasta irmã `Central_Validacao_Cadastral`, versão 0.9.2-prototipo. Esta aplicação de meios de comunicação é independente.

O pacote de referência `Central_Validacao_Cadastral_v0.9.2-prototipo.zip` foi preservado. SHA-256 antes das alterações:

`10FD9D4AF1A431051A607A6BBF4F793093989AD384F2FE487B9BA9F7820C500D`

Foram reaproveitados apenas utilitários locais de leitura XLSX/CSV, a biblioteca de compactação e as convenções de rastreabilidade. O motor de auditoria, as regras de comunicação, os indicadores e a interface são novos. Os logos foram copiados do HUB fornecido, sem alterar a origem.
