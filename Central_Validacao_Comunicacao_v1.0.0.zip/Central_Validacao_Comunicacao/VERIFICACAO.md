# Verificação da versão 1.0.0

Data de referência da verificação: 06/10/2026.

- 30 verificações de regras, mapeamento, datas, marcadores de ausência, rastreabilidade, tabelas gerenciais, escrita/releitura XLSX e estrutura offline aprovadas.
- 11 verificações de interação em ambiente DOM simulado aprovadas: demonstração, processamento, filtros, paginação 20/100/todos, seleção por grupo, exportação e invalidação de resultados após mudança de escopo.
- Exportação de 26.001 registros sintéticos em arquivos Excel de até 25 mil linhas, seguida de releitura e reconciliação, aprovada. Exportação de canais também reconciliada.
- Base de referência completa: 128.924 registros, 23 colunas, 124.204 pessoas identificadas, nenhuma linha perdida ou vazia ignorada. Leitura e processamento completos em aproximadamente 11 segundos no ambiente de teste Node; o tempo no navegador depende do dispositivo.
- Com todas as 17 regras selecionadas: 393 registros sem achados, 119.163 com alertas e 9.368 com erros. Cobertura estrutural em 128.824 registros; 100 sem canal válido. As categorias reconciliam com o universo. Alertas de zeros de preenchimento nos DDDs têm alta frequência e podem ser desmarcados para focar nos erros objetivos.
- Os valores originais da base real não foram incluídos no pacote. A demonstração é fictícia.
- A abertura automatizada de URLs file:// foi bloqueada pela política do navegador integrado. A revisão visual renderizada e a impressão real em navegador não foram realizadas. O teste de interação não substitui inspeção visual. O aplicativo pode ser aberto manualmente pelo usuário no Edge/Chrome.

O ZIP do validador cadastral geral permaneceu com o SHA-256 registrado em REFERENCIA_VALIDADOR.md.
