(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ComSchema=api;})(globalThis,function(){
  'use strict';
  const labels=['Id PF','Nome Participante','Nome Patrocinador','Data Nascimento','Idade','Sexo','Caixa Postal','DDD Telefone 1','Telefone 1','DDD Telefone 2','Telefone 2','DDD Celular 1','Celular 1','DDD Celular 2','Celular 2','Email 1','Email 2','Email 3','Data Óbito','Nome Plano','Matrícula Petros','Situação','Tipo Benefício'];
  const ids=['id','nome','patrocinador','nascimento','idade','sexo','caixa','ddd_tel1','tel1','ddd_tel2','tel2','ddd_cel1','cel1','ddd_cel2','cel2','email1','email2','email3','obito','plano','matricula','situacao','beneficio'];
  const fields=ids.map((id,index)=>({id,label:labels[index],index}));
  const channels=[{id:'tel1',label:'Telefone 1',type:'fixo',ddd:'ddd_tel1'},{id:'tel2',label:'Telefone 2',type:'fixo',ddd:'ddd_tel2'},{id:'cel1',label:'Celular 1',type:'celular',ddd:'ddd_cel1'},{id:'cel2',label:'Celular 2',type:'celular',ddd:'ddd_cel2'},{id:'email1',label:'E-mail 1',type:'email'},{id:'email2',label:'E-mail 2',type:'email'},{id:'email3',label:'E-mail 3',type:'email'}];
  const rules=[
    ['ddd','Telefones e celulares','DDD existente','DDD brasileiro com dois dígitos, existente na tabela de códigos nacionais.','Erro'],
    ['pair','Telefones e celulares','Par DDD e número','Identifica DDD sem número e número local sem DDD.','Erro'],
    ['length','Telefones e celulares','Quantidade de dígitos','Fixo com 8 dígitos; celular com 9. DDD incorporado é interpretado para revisão.','Erro'],
    ['prefix','Telefones e celulares','Prefixo do serviço','Fixo inicia em 2, 3, 4 ou 5; celular inicia em 9.','Erro'],
    ['characters','Telefones e celulares','Caracteres permitidos','Aceita dígitos e máscara usual. Texto, ramal e múltiplos números exigem tratamento.','Erro'],
    ['dummy','Telefones e celulares','Padrão numérico suspeito','Sinaliza dígitos repetidos e sequências de exemplo para confirmar legitimidade.','Alerta'],
    ['format','Telefones e celulares','Padronização dos campos','Sinaliza máscara, DDD/DDI incorporado e zero de discagem. Sugere sem alterar a origem.','Alerta'],
    ['email_syntax','E-mails','Estrutura do e-mail','Uma caixa por campo, @ único, domínio com ponto e limites de comprimento.','Erro'],
    ['email_dummy','E-mails','Possível endereço de exemplo','Sinaliza placeholders como teste, sememail, não informado e example.com para revisão.','Alerta'],
    ['email_format','E-mails','Espaços e caixa','Sinaliza espaços externos e maiúsculas no domínio. Preserva a caixa da parte local.','Alerta'],
    ['email_typo','E-mails','Domínio possivelmente digitado errado','Aponta lista conservadora de erros comuns. A sugestão precisa de confirmação.','Alerta'],
    ['repeat','Cruzamentos','Repetição entre campos','Mesmo contato repetido em mais de um campo do registro.','Alerta'],
    ['shared','Cruzamentos','Contato compartilhado','Mesmo contato associado a pessoas distintas. Não considera repetição da pessoa em planos.','Alerta'],
    ['no_contact','Cruzamentos','Sem canal estruturalmente válido','Nenhum contato atende ao padrão técnico entre os canais mapeados.','Erro'],
    ['identity','Contexto da auditoria','Identificação e vínculo','Chave ausente e repetição da combinação pessoa, plano, situação e benefício.','Alerta'],
    ['age','Contexto da auditoria','Idade e nascimento','Data inválida/futura, idade fora de 0–120 e diferença acima de um ano da idade informada.','Alerta'],
    ['death','Contexto da auditoria','Data de óbito','Marca data de óbito informada e datas inválidas/futuras para revisão do público.','Alerta']
  ].map(([id,group,label,description,severity])=>({id,group,label,description,severity,default:true}));
  const dddUF={};
  const ufCodes={SP:'11 12 13 14 15 16 17 18 19',RJ:'21 22 24',ES:'27 28',MG:'31 32 33 34 35 37 38',PR:'41 42 43 44 45 46',SC:'47 48 49',RS:'51 53 54 55',DF:'61',GO:'62 64',TO:'63',MT:'65 66',MS:'67',AC:'68',RO:'69',BA:'71 73 74 75 77',SE:'79',PE:'81 87',AL:'82',PB:'83',RN:'84',CE:'85 88',PI:'86 89',PA:'91 93 94',AM:'92 97',RR:'95',AP:'96',MA:'98 99'};
  Object.entries(ufCodes).forEach(([uf,list])=>list.split(' ').forEach(d=>dddUF[d]=uf));
  const version='1.0.0';
  return {fields,channels,rules,dddUF,version,labels};
});
