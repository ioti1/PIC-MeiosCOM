(function(root,factory){const S=typeof module==='object'&&module.exports?require('./schema.js'):root.ComSchema;const api=factory(S);if(typeof module==='object'&&module.exports)module.exports=api;else root.ComAudit=api;})(globalThis,function(S){
  'use strict';
  const str=v=>v==null?'':String(v).trim();
  const norm=v=>str(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
  const digits=v=>str(v).replace(/\D/g,'');
  function isMissing(v){return !str(v)||['-','--','NULL','(NULL)','N/A','NAN','NONE'].includes(norm(v));}
  function isMissingDate(v){return isMissing(v)||['00/00/0000','0000-00-00','00000000'].includes(str(v));}
  const category=v=>isMissing(v)?'':str(v);
  function date(v){if(v instanceof Date)return Number.isNaN(+v)?null:v;const t=str(v);if(!t)return null;if(/^\d+(\.\d+)?$/.test(t)&&+t>0&&+t<100000)return new Date(Math.floor(+t-25569)*86400000);let m=t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);if(!m){m=t.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);if(m)m=[m[0],m[3],m[2],m[1]];}if(!m)return null;const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return d.getUTCFullYear()===+m[1]&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[3]?d:null;}
  function ageAt(d,ref){if(!d||!ref||d>ref)return null;return ref.getUTCFullYear()-d.getUTCFullYear()-(ref.getUTCMonth()<d.getUTCMonth()||(ref.getUTCMonth()===d.getUTCMonth()&&ref.getUTCDate()<d.getUTCDate())?1:0);}
  function ageBand(n){return n==null?'Não disponível':n<0||n>120?'Fora do intervalo':n<18?'Até 17':n<30?'18–29':n<45?'30–44':n<60?'45–59':n<75?'60–74':'75+';}
  function autoMap(headers){const result={};const used=new Set();const clean=headers.map(norm);S.fields.forEach(f=>{let i=clean.findIndex((h,j)=>!used.has(j)&&h===norm(f.label));if(i<0&&headers.length===23)i=f.index;if(i>=0){result[f.id]=i;used.add(i);}});return result;}
  const typos={'gamil.com':'gmail.com','gmial.com':'gmail.com','gmail.con':'gmail.com','gmail.com.br':'gmail.com','hotmai.com':'hotmail.com','hotmial.com':'hotmail.com','hotmail.con':'hotmail.com','outlok.com':'outlook.com','outlook.con':'outlook.com','yahoo.con':'yahoo.com'};
  function checkChannel(ch,raw,dddRaw,mapped=true,dddMapped=true){
    const t=isMissing(raw)?'':str(raw), dr=isMissing(dddRaw)?'':str(dddRaw), findings=[];
    const add=(rule,message,suggestion='')=>findings.push({rule,message,suggestion});
    if(!mapped)return {id:ch.id,type:ch.type,label:ch.label,present:false,valid:null,normalized:'',findings:[],state:'Não avaliado',raw:'',ddd:''};
    let normalized='',valid=false,present=!!t,uf='';
    if(ch.type==='email'){
      const at=t.lastIndexOf('@');const local=at<0?t:t.slice(0,at);const domain=at<0?'':t.slice(at+1).toLowerCase();normalized=at<0?t:local+'@'+domain;
      if(t){
        const syntax=t.length<=254&&local.length<=64&&/^[A-Za-z0-9!#$%&'*+\-/=?^_`{|}~]+(?:\.[A-Za-z0-9!#$%&'*+\-/=?^_`{|}~]+)*@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$/.test(t)&&domain.split('.').every(p=>p.length<=63)&&/[a-z]{2,}$/i.test(domain);
        const dummy=/^(teste\d*|test\d*|sememail|naoinformado|naopossui|xxx|abc)$/i.test(norm(local).replace(/[ ._-]/g,''))||['example.com','example.org','exemplo.com','teste.com'].includes(domain)||['NAO INFORMADO','SEM EMAIL','N/A','NAO POSSUI'].includes(norm(t));
        if(!syntax)add('email_syntax','Estrutura de e-mail inválida. Informe apenas um endereço por campo.');
        if(dummy)add('email_dummy','Endereço pode indicar exemplo ou ausência de informação; confirmar legitimidade.');
        if(String(raw)!==t||t!==normalized)add('email_format','Padronizar espaços externos e domínio do e-mail.',normalized);
        if(typos[domain])add('email_typo','Domínio possivelmente incorreto; confirmar com o participante.',local+'@'+typos[domain]);
        valid=syntax;
      }
    }else{
      let number=digits(t),ddd=digits(dr);const size=ch.type==='celular'?9:8;
      if(/^0+\d{2}$/.test(ddd))ddd=ddd.slice(-2);
      const original=number;
      if((number.length===12||number.length===13)&&number.startsWith('55'))number=number.slice(2);
      if(number.length===10||number.length===11){const embedded=number.slice(0,2);if(!ddd)ddd=embedded;else if(ddd!==embedded)add('pair','DDD do campo difere do DDD incorporado no número.');number=number.slice(2);}
      if(ddd.length===3&&ddd.startsWith('0'))ddd=ddd.slice(1);
      const okDDD=!!S.dddUF[ddd]&&/^\d{2}$/.test(ddd);uf=S.dddUF[ddd]||'';
      normalized=number;present=!!t||!!dr;
      if(present){
        if(!t||(!ddd&&t))add('pair',!t?'DDD preenchido sem número.':'Número local preenchido sem DDD.');
        if((t||dr)&&!okDDD)add('ddd','DDD não pertence à tabela brasileira de códigos nacionais.',okDDD?ddd:'');
        if(t&&number.length!==size)add('length',`Número ${ch.type==='celular'?'celular':'fixo'} deve ter ${size} dígitos, sem DDD.`);
        if(t&&!(ch.type==='celular'?/^9/:/^[2-5]/).test(number))add('prefix',ch.type==='celular'?'Celular deve iniciar em 9.':'Telefone fixo deve iniciar em 2, 3, 4 ou 5.');
        if((t&&!/^\+?[\d\s().-]+$/.test(t))||(dr&&!/^[\d\s()-]+$/.test(dr)))add('characters','Há texto ou separadores incompatíveis com um único número.');
        if(t&&(/^(\d)\1+$/.test(number)||['12345678','123456789','987654321','912345678'].includes(number)))add('dummy','Número repetitivo ou sequência típica de exemplo; confirmar legitimidade.');
        if(t&&(t!==number||dr!==ddd||original!==number))add('format',`Padronizar número e DDD em campos separados${!dddMapped?' (coluna DDD não mapeada)':''}.`,`DDD ${ddd}; número ${number}`);
        valid=!!t&&!findings.some(f=>!['format','dummy'].includes(f.rule));
      }
      return {id:ch.id,type:ch.type,label:ch.label,present,valid:present?valid:false,normalized,ddd,uf,raw:str(raw),findings,state:present?(valid?'Válido':'Inválido'):'Ausente'};
    }
    return {id:ch.id,type:ch.type,label:ch.label,present,valid:present?valid:false,normalized,ddd:'',uf,raw:str(raw),findings,state:present?(valid?'Válido':'Inválido'):'Ausente'};
  }
  async function process({rows,mapping,selection,referenceDate,firstDataRow=2,onProgress,cancelled}){
    const selected=new Set(selection||S.rules.map(r=>r.id));const definitions=Object.fromEntries(S.rules.map(r=>[r.id,r]));
    const ref=date(referenceDate)||new Date();const records=[];const owners=new Map();const identities=new Map();const people=new Set();let ignored=0;
    const mappedChannels=S.channels.filter(c=>mapping[c.id]!=null).length;
    for(let i=0;i<rows.length;i++){
      if(cancelled?.())throw new Error('Processamento cancelado.');
      const row=rows[i];if(row.every(v=>!str(v))){ignored++;continue;}
      const get=id=>mapping[id]==null?'':row[mapping[id]];
      const idPF=category(get('id')),matricula=category(get('matricula'));
      const key=idPF?'PF:'+idPF:matricula?'MP:'+matricula:'';const person=key||`SEM_CHAVE_LINHA_${i+firstDataRow}`;
      if(key)people.add(person);
      const birth=isMissingDate(get('nascimento'))?null:date(get('nascimento'));const provided=isMissing(get('idade'))?null:Number(get('idade'));const calculated=ageAt(birth,ref);const age=calculated!=null?calculated:Number.isFinite(provided)&&provided>=0&&provided<=120?provided:null;
      const rec={index:i,rowNumber:i+firstDataRow,person,key,matricula,nome:category(get('nome')),plano:category(get('plano'))||'Não informado',situacao:category(get('situacao'))||'Não informado',patrocinador:category(get('patrocinador'))||'Não informado',beneficio:category(get('beneficio'))||'Não informado',sexo:category(get('sexo'))||'Não informado',age,ageBand:ageBand(age),ageSource:calculated!=null?'Nascimento':age!=null?'Idade informada':'Não disponível',obito:!isMissingDate(get('obito')),channels:[],issues:[],status:'Consistente',errors:0,warnings:0};
      function add(rule,field,message,suggestion='',raw=''){if(selected.has(rule)){const d=definitions[rule];rec.issues.push({rule,ruleLabel:d.label,severity:d.severity,field,message,suggestion,raw});}}
      for(const ch of S.channels){const c=checkChannel(ch,get(ch.id),get(ch.ddd),mapping[ch.id]!=null,mapping[ch.ddd]!=null);rec.channels.push(c);c.findings.forEach(f=>add(f.rule,ch.label,f.message,f.suggestion,c.raw));if(c.present&&c.normalized){const k=(c.type==='email'?'email:':'fone:')+(c.ddd||'')+(c.type==='email'?c.normalized.toLowerCase():c.normalized);if(!owners.has(k))owners.set(k,{first:person,shared:false});else if(owners.get(k).first!==person)owners.get(k).shared=true;c.contactKey=k;}}
      const repeats=new Set();for(const c of rec.channels){if(!c.present||!c.contactKey)continue;if(repeats.has(c.contactKey))add('repeat',c.label,'Contato repetido em outro campo deste registro.','',c.raw);repeats.add(c.contactKey);}
      rec.validChannels=rec.channels.filter(c=>c.valid===true).length;rec.presentChannels=rec.channels.filter(c=>c.present).length;rec.coverage=mappedChannels?rec.validChannels>0?'Com canal válido':'Sem canal válido':'Não avaliado';
      if(mappedChannels&&rec.validChannels===0)add('no_contact','Cobertura','Nenhum canal mapeado atende ao padrão técnico.');
      if(!key)add('identity','Identificação','Sem Id PF e sem Matrícula Petros; não é possível conciliar a pessoa.');
      const identity=person+'|'+JSON.stringify([rec.plano,rec.situacao,rec.beneficio]);identities.set(identity,(identities.get(identity)||0)+1);rec.identity=identity;
      if(mapping.nascimento!=null&&!isMissingDate(get('nascimento'))&&(!birth||birth>ref))add('age','Data Nascimento','Data de nascimento inválida ou posterior à referência.','',str(get('nascimento')));
      if(provided!=null&&(!Number.isFinite(provided)||provided<0||provided>120))add('age','Idade','Idade informada fora do intervalo 0–120.','',str(get('idade')));
      if(calculated!=null&&(calculated>120||provided!=null&&Number.isFinite(provided)&&Math.abs(calculated-provided)>1))add('age','Idade','Idade calculada diverge da informada ou excede 120 anos.','Confirmar referência e nascimento',str(get('idade')));
      if(rec.obito)add('death','Data Óbito',!date(get('obito'))||date(get('obito'))>ref?'Data de óbito inválida ou futura.':'Óbito informado: revisar elegibilidade do público de comunicação.','',str(get('obito')));
      records.push(rec);
      if(i%1500===0){onProgress?.({percent:Math.round(i/rows.length*80),phase:'Validando estrutura e contexto'});await new Promise(r=>setTimeout(r,0));}
    }
    for(let i=0;i<records.length;i++){const r=records[i];if(selected.has('shared'))for(const c of r.channels)if(c.contactKey&&owners.get(c.contactKey)?.shared)r.issues.push({rule:'shared',ruleLabel:definitions.shared.label,severity:'Alerta',field:c.label,message:'Contato associado a pessoas distintas; confirmar compartilhamento legítimo.',suggestion:'',raw:c.raw});if(selected.has('identity')&&identities.get(r.identity)>1)r.issues.push({rule:'identity',ruleLabel:definitions.identity.label,severity:'Alerta',field:'Vínculo',message:'Combinação pessoa, plano, situação e benefício repetida na base.',suggestion:'',raw:''});r.errors=r.issues.filter(f=>f.severity==='Erro').length;r.warnings=r.issues.length-r.errors;r.status=r.errors?'Inconsistente':r.warnings?'Com ressalvas':selected.size?'Consistente':'Não avaliado';if(i%3000===0){if(cancelled?.())throw new Error('Processamento cancelado.');onProgress?.({percent:80+Math.round(i/records.length*20),phase:'Conciliando contatos compartilhados'});await new Promise(r=>setTimeout(r,0));}}
    return {records,summary:summarize(records),people:people.size,ignored,mappedChannels,referenceDate:ref.toISOString().slice(0,10),selection:[...selected],version:S.version,runId:globalThis.crypto?.randomUUID?.()||`exec-${Date.now()}-${Math.random().toString(36).slice(2)}`,processedAt:new Date().toISOString()};
  }
  function summarize(records){const total=records.length;return {total,pass:records.filter(r=>r.status==='Consistente').length,warn:records.filter(r=>r.status==='Com ressalvas').length,fail:records.filter(r=>r.status==='Inconsistente').length,unassessed:records.filter(r=>r.status==='Não avaliado').length,covered:records.filter(r=>r.coverage==='Com canal válido').length,uncovered:records.filter(r=>r.coverage==='Sem canal válido').length,issues:records.reduce((n,r)=>n+r.issues.length,0)};}
  function group(records,dimension){const groups=new Map();for(const r of records){const k=String(r[dimension]??'Não disponível');if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);}return [...groups].map(([label,rows])=>({label,...summarize(rows),people:new Set(rows.filter(r=>r.key).map(r=>r.person)).size})).sort((a,b)=>b.total-a.total||a.label.localeCompare(b.label));}
  return {str,norm,digits,isMissing,isMissingDate,date,ageAt,ageBand,autoMap,checkChannel,process,summarize,group};
});
