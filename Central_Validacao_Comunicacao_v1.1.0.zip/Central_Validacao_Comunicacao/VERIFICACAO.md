# Verificação da versão 1.1.0

Verificação realizada em 08/10/2026.

- 30 verificações legadas de regras, leitura/escrita Excel, datas e estrutura offline aprovadas.
- 22 testes de mensagens detalhadas, classificação, DDD com zeros neutros, origem/fotografia, escopo por fonte e cruzamentos restritos à mesma fotografia aprovados.
- 23 testes de concatenação, preservação de extras, filtros combinados, máscara, tratamento/reabertura e restauração segura aprovados. Um caso de restauração após mudar o mapeamento foi reproduzido e corrigido com assinatura do mapeamento.
- 9 testes de fatos gerenciais, chaves, riscos/problemas, fontes, grupos contratuais, tratamento e tipos nativos de data/número aprovados.
- 18 verificações de interação em DOM simulado aprovadas: múltiplos CSVs, fotografia obrigatória por fonte, filtros de regra, pendências, andamento, evidência, conteúdo PDF, paginação e exportação.
- Exportação/releitura de 26.001 registros em blocos Excel, sem perda, e exportação de canais aprovadas.
- Base real: 128.924 linhas preservadas. Classificação: Ativos 52.751; Assistidos 76.173, sendo Pensionista 21.047 e Aposentado(a) 55.126. Nenhuma situação sem classificação nessa referência. Leitura/validação do motor em aproximadamente 12,3 segundos no ambiente Node; não é estimativa para todos os navegadores.
- A data usada na prova do motor é uma referência de teste, não uma declaração da fotografia real. No uso do aplicativo o usuário precisa informar a fotografia de cada base.
- Imagem ilustrativa Power BI: PNG 1600×1000 renderizado com biblioteca gráfica e inspecionado. HTML da prévia usa dados sintéticos explicitamente identificados; suas opções de filtro foram verificadas em DOM simulado.
- A revisão visual da aplicação e a impressão real em navegador permanecem não verificadas devido ao bloqueio de file:// do navegador integrado registrado nesta conversa. Testes de conteúdo/fluxo não equivalem à inspeção do layout renderizado. O usuário pode abrir manualmente o HTML em Edge/Chrome.

O pacote não contém a base real. A versão 1.0.0 e o validador geral anterior foram preservados em seus ZIPs.
