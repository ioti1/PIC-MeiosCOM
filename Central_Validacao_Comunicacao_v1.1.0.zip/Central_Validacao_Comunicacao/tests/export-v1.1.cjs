const assert=require('node:assert/strict');
global.JSZip=require('../vendor/jszip.min.js');
const S=require('../src/schema.js'),A=require('../src/audit.js'),E=require('../src/export.js'),X=require('../src/xlsx.js');
let count=0;
function test(label,fn){fn();count++;console.log('✓ '+label);}
function objects(table){const [header,...rows]=[...table];return rows.map(row=>Object.fromEntries(header.map((key,index)=>[key,row[index]])));}
const mapping=Object.fromEntries(S.fields.map(field=>[field.id,field.index]));
function sourceRow(id,cell1,cell2='',situation='Ativo',benefit='Sem benefício'){
  return [id,'Participante '+id,'Patrocinadora Alfa','20/05/1980',46,'F','','21','23456789','','','21',cell1,cell2?'21':'',cell2,id+'@dominio.org','','','','Plano A','00000'+id,situation,benefit];
}
(async()=>{
  const rows=[sourceRow('1','91234','92345'),sourceRow('2','93456','','Assistido','PENSÃO POR MORTE'),sourceRow('3','945678901','','Assistido','APOSENTADORIA')];
  const result=await A.process({rows,mapping,selection:['length'],referenceDate:'2026-10-08'});
  const sources=[{id:'sha-a',filename:'base_a.xlsx',sheet:'Dados A',snapshotDate:'2026-10-08',headerRow:1,headers:S.labels,rows:[rows[0]],mapping,book:{notExported:'CONTEUDO_NAO_SERIALIZAR'}},{id:'sha-b',filename:'nome_livre.xlsx',sheet:'Dados B',snapshotDate:'2026-10-08',headerRow:1,headers:S.labels,rows:rows.slice(1),mapping}];
  result.records.forEach((record,index)=>{
    const source=sources[index===0?0:1];
    Object.assign(record,{recordId:source.id+'|'+source.sheet+'|'+(index===2?3:2),sourceId:source.id,sourceFile:source.filename,sourceSheet:source.sheet,sourceRow:index===2?3:2,rowNumber:index===2?3:2,contractGroup:index===0?'Ativos':'Assistidos',contractSubgroup:['Ativo','Pensionista','Aposentado(a)'][index],treatmentStatus:['Tratado','Pendente','Sem pendência'][index],treatedAt:index===0?'2026-10-08T15:30:00.000Z':''});
    record.issues.forEach(issue=>Object.assign(issue,{risk:'Estrutura dos contatos',problem:'Quantidade de dígitos insuficiente',observedDigits:5,expectedDigits:9,digitDelta:-4}));
  });
  const state={rows,headers:S.labels,mapping,result,sources,filename:'Base concatenada',sheet:'Múltiplas abas',headerRow:1};
  const records=objects(E.recordRows(state)),issues=objects(E.issueRows(state)),treatment=objects(E.treatmentRows(state)),risks=objects(E.riskRows(state)),publics=objects(E.publicRows(state)),indicators=objects(E.indicatorRows(state));
  test('mesma linha física em bases diferentes mantém chaves distintas nos fatos',()=>{
    assert.equal(new Set(records.map(record=>record.Id_Registro)).size,3);
    assert.equal(records[0].Linha_Fisica_Origem,2);assert.equal(records[1].Linha_Fisica_Origem,2);
    assert.equal(records[0].Arquivo_Origem,'base_a.xlsx');assert.equal(records[1].Arquivo_Origem,'nome_livre.xlsx');
    assert.ok(issues.every(issue=>records.some(record=>record.Id_Registro===issue.Id_Registro)));
    assert.equal(new Set(issues.map(issue=>issue.Id_Achado)).size,issues.length);
  });
  test('origem, classificação e tratamento coexistem com situação original',()=>{
    assert.equal(records[1].Situacao,'Assistido');assert.equal(records[1].Grupo_Contratual,'Assistidos');assert.equal(records[1].Subgrupo_Contratual,'Pensionista');
    assert.equal(treatment[1]['Situação'],'Assistido');assert.equal(treatment[1].Subgrupo_Contratual,'Pensionista');
    assert.equal(treatment[0].Status_Tratamento,'Tratado');assert.equal(treatment[0].Tratado,1);assert.equal(treatment[0].Pendente,0);
    assert.equal(treatment[0].Tratado_Em_UTC,'2026-10-08T15:30:00.000Z');assert.equal(treatment[0]['DATA DO TRATAMENTO'],'2026-10-08T15:30:00.000Z');
    assert.equal(treatment[2]['Nome Participante'],'Participante 3');assert.ok(treatment[2]['Data Nascimento'] instanceof Date);
  });
  test('achados exportam quantidade exata de dígitos para tratamento em lote',()=>{
    assert.equal(issues.length,3);for(const issue of issues){assert.equal(issue.Risco_Principal,'Estrutura dos contatos');assert.equal(issue.Problema_Especifico,'Quantidade de dígitos insuficiente');assert.equal(issue.Digitos_Observados,5);assert.equal(issue.Digitos_Esperados,9);assert.equal(issue.Diferenca_Digitos,-4);assert.equal(issue.Digitos_Faltantes,4);assert.equal(issue.Digitos_Excedentes,0);}
  });
  test('matriz de risco distingue achados de registros afetados e tratados',()=>{
    assert.equal(risks.length,1);assert.equal(risks[0].Achados,3);assert.equal(risks[0].Registros_Afetados,2);assert.equal(risks[0].Registros_Pendentes,1);assert.equal(risks[0].Registros_Tratados,1);
  });
  test('recortes contratuais por patrocinadora e plano conciliam universo e tratamento',()=>{
    assert.equal(publics.reduce((sum,row)=>sum+row.Registros,0),3);assert.equal(publics.reduce((sum,row)=>sum+row.Pendentes,0),1);assert.equal(publics.reduce((sum,row)=>sum+row.Tratados,0),1);assert.equal(publics.reduce((sum,row)=>sum+row.Sem_Pendencia,0),1);
    assert.ok(publics.some(row=>row.Grupo_Contratual==='Assistidos'&&row.Subgrupo_Contratual==='Pensionista'&&row.Patrocinador==='Patrocinadora Alfa'&&row.Plano==='Plano A'));
    const total=indicators.find(row=>row.Dimensao==='Total');assert.equal(total.Pendentes+total.Tratados+total.Sem_Pendencia,total.Registros);
    assert.equal(indicators.filter(row=>row.Dimensao==='contractGroup').reduce((sum,row)=>sum+row.Registros,0),3);
  });
  test('fontes exportam somente metadados do layout e contagens por origem',()=>{
    const table=objects(E.sourceRows(state));assert.equal(table.length,2);assert.equal(table[0].Linhas_Importadas,1);assert.equal(table[1].Linhas_Importadas,2);assert.equal(table[0].Registros_Processados,1);assert.equal(table[1].Registros_Processados,2);assert.ok(!JSON.stringify(table).includes('CONTEUDO_NAO_SERIALIZAR'));
    const execution=objects(E.executionRows(state))[0];assert.equal(execution.Quantidade_Fontes,2);assert.equal(execution.Pendentes,1);assert.equal(execution.Tratados,1);
  });
  test('exportação de contatos respeita o subconjunto solicitado e a nova chave',()=>{
    const contacts=objects(E.tables(state,'contacts',[result.records[1]]).Fato_Contatos);assert.equal(contacts.length,7);assert.ok(contacts.every(row=>row.Id_Registro===result.records[1].recordId));
  });
  test('fotografias de datas diferentes permanecem separadas em indicadores, riscos e recortes',()=>{
    const photoRecords=result.records.map((record,index)=>({...record,snapshotDate:index===0?'2026-09-01':'2026-10-01',contractGroup:'Ativos',contractSubgroup:'Ativo'}));
    const photoState={...state,result:{...result,records:photoRecords},sources:sources.map((source,index)=>({...source,snapshotDate:index===0?'2026-09-01':'2026-10-01'}))};
    const totals=objects(E.indicatorRows(photoState)).filter(row=>row.Dimensao==='Total');assert.equal(totals.length,2);assert.deepEqual(totals.map(row=>row.Registros),[1,2]);
    const matrix=objects(E.riskRows(photoState));assert.equal(matrix.length,2);assert.deepEqual(matrix.map(row=>row.Achados).sort(),[1,2]);
    const slices=objects(E.publicRows(photoState));assert.equal(slices.length,2);assert.deepEqual(slices.map(row=>row.Registros).sort(),[1,2]);
    for(const table of [E.recordRows(photoState),E.issueRows(photoState),E.contactRows(photoState),E.treatmentRows(photoState),E.sourceRows(photoState)]){
      const values=objects(table);assert.ok(values.every(row=>row.Data_Fotografia instanceof Date));assert.ok(values.some(row=>row.Data_Fotografia.toISOString().startsWith('2026-09-01')));assert.ok(values.some(row=>row.Data_Fotografia.toISOString().startsWith('2026-10-01')));
    }
    assert.equal(objects(E.executionRows(photoState))[0].Quantidade_Fotografias,2);
  });
  const output=await E.generate(state,'bi'),zip=await JSZip.loadAsync(await output.blob.arrayBuffer());
  const workbookXml=await zip.file('xl/workbook.xml').async('string'),recordsXml=await zip.file('xl/worksheets/sheet2.xml').async('string');
  const read=await X.read({name:'auditoria.xlsx',arrayBuffer:async()=>output.blob.arrayBuffer()});
  test('Excel final contém fatos, matriz, recortes e fontes com números e datas nativas',()=>{
    assert.equal(output.extension,'xlsx');for(const sheet of ['Fontes','Matriz_Risco','Recortes_Publico'])assert.ok(read[sheet],sheet);
    assert.match(workbookXml,/name="Fontes"/);assert.match(recordsXml,/<c r="B2" s="4"><v>\d+<\/v>/);assert.match(recordsXml,/<c r="D2" s="0"><v>2<\/v>/);assert.ok(!recordsXml.includes('<f>'));
    const fact=objects(read.Fato_Registros);assert.equal(fact[0].Matricula_Petros,'000001');assert.equal(fact[0].Id_Registro,result.records[0].recordId);
    assert.equal(objects(read.Fato_Achados)[0].Digitos_Faltantes,'4');
  });
  console.log('\n'+count+' verificações de exportação v1.1 aprovadas.');
})().catch(error=>{console.error(error);process.exitCode=1;});
