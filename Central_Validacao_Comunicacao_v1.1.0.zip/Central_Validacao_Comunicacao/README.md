# Petros — Qualidade dos Meios de Comunicação

Aplicação local e offline para pré-validar DDDs, telefones fixos, celulares e e-mails. Abra `index.html` no Edge ou Chrome. O validador cadastral anterior foi preservado em sua pasta e no pacote v0.9.2. A versão anterior desta ferramenta permanece no ZIP v1.0.0; esta é a versão 1.1.0.

## Uso

1. Importe um ou mais XLSX, CSV ou TXT. Novas seleções acrescentam arquivos ao lote. O mesmo arquivo com mesmo nome e conteúdo não é adicionado duas vezes.
2. Selecione cada base na lista e revise aba, cabeçalho e mapeamento. Informe a **data da fotografia** de cada base: de qual dia/mês/ano são os dados. Essa data é obrigatória e não é inferida do nome nem da última modificação do arquivo. A data da avaliação identifica a referência da execução, separadamente.
3. Os campos de cada fonte são alinhados ao layout comum e concatenados antes da validação. O nome não define o padrão. Campos não mapeados ou adicionais são preservados em colunas “Original · …”. Não há eliminação automática de registros repetidos entre arquivos.
4. Selecione regras e execute. Explore fotografia, Ativos/Assistidos, subgrupo, plano, patrocinadora e idade. Os filtros gerenciais afetam a tela e o PDF; “Investigar registros” transfere os recortes disponíveis para a fila.
5. Na fila, filtre Resultado, Matrícula/Id PF/nome, Cobertura, Plano e demais campos. Regra lista somente os achados dos registros retornados por esses critérios; uma regra que deixa de existir no recorte é removida da seleção. Problema permite separar faltas/excessos exatos de dígitos e outros defeitos para tratamento em lote.
6. Marque o registro como **Tratado** para retirá-lo da contagem de pendências. “Reabrir” devolve a pendência. Salve o andamento em JSON antes de fechar e restaure-o posteriormente. A tela mostra 20, 100 ou todos por página.
7. Exporte tratamento, fatos gerenciais e canais. Para PDF, escolha “Salvar como PDF” na impressão. O relatório contém fotografias e separações por situação agrupada/subgrupo, patrocinadora e plano. “Prévia Power BI” abre uma proposta interativa com dados sintéticos.

## Definições de auditoria

- Registro: uma linha não vazia de uma fonte e fotografia, conservando arquivo, aba e linha física de origem. Chave única inclui fonte, aba, linha e fotografia; duas bases com linha 2 não colidem. Não é necessariamente uma pessoa única.
- Pessoa única: Id PF, com Matrícula Petros como alternativa. As chaves recebem prefixos PF/MP para impedir colisões. Registros sem chave não entram no total de pessoas únicas. Pessoas únicas por plano não são aditivas.
- Consistente: sem achados nas regras selecionadas. Com ressalvas: alertas, sem erros. Inconsistente: ao menos um erro.
- Cobertura técnica: ao menos um canal mapeado com estrutura válida, calculada independentemente das regras selecionadas. Não confirma entrega, titularidade ou linha ativa. Sequências suspeitas, placeholders e erros possíveis de domínio geram alertas separados; não comprovam impossibilidade técnica de uso.
- Canal ausente: campo vazio ou marcador técnico de ausência (`-`, `--`, `NULL`, `(NULL)`, `N/A`, `NaN`, `None`). O hífen é o padrão de ausência observado na base fornecida. Esses valores são preservados na origem exportada, mas não geram falsos erros de sintaxe, repetição ou compartilhamento. Datas zeradas também representam ausência. Campos individuais são opcionais; a regra de ausência de canal válido avalia o conjunto mapeado. Canal não mapeado fica “Não avaliado”.
- Idade: calculada pelo nascimento na data da fotografia individual. Se indisponível, usa a idade informada entre 0 e 120. Divergência acima de um ano gera alerta quando a regra está selecionada.
- Contato compartilhado: contato normalizado associado a pessoas distintas na mesma fotografia; um alerta para confirmar compartilhamento legítimo. A mesma pessoa em dois planos não gera esse alerta. Fotografias diferentes não são cruzadas como se fossem contemporâneas.
- Óbito: informação é sinalizada para revisão do público quando a regra está selecionada. Nenhum registro é excluído automaticamente.
- Tratado: encerramento operacional da pendência pelo usuário. Mantém achados e resultado da auditoria originais; não comprova correção na base. Para medir melhoria estrutural, reimporte a base corrigida em nova fotografia. A marca só é restaurada para conteúdo do arquivo, fotografia, mapeamento, versão e conjunto de regras equivalentes.

## Classificação contratual

Ativos contém: Ativo-Aguardando Deferimento, Ex-Aguardando Deferimento, Assistido-Aguardando Deferimento, Ativo, Remido, Autopatrocinado e Optante pelo BPO. A variante da referência “EX-PARTICIPANTE AGUARDANDO DEFERIMENTO” é padronizada como Ex-Aguardando Deferimento.

Assistidos é dividido pelo texto do Tipo Benefício: contendo `PENS`, Pensionista; qualquer outro benefício, Aposentado(a). Trata-se da classificação operacional solicitada, inclusive para benefícios de auxílio que não contêm PENS. A situação e o benefício originais continuam no Excel. Novas situações sem correspondência ficam explicitamente “Não classificado”, para revisão, em vez de serem presumidas como Assistidos.

A sintaxe de e-mail cobre endereços usuais com caracteres ASCII e domínio com ponto. Endereços internacionalizados e sintaxes especiais com parte local entre aspas exigem revisão. A lista de possíveis erros de domínio é conservadora e configurada em `src/audit.js`; sugestões não são aplicadas automaticamente. Maiúsculas na parte local do e-mail são preservadas.

O escopo de telefonia é Brasil. São interpretadas máscaras, DDD incorporado, código do país 55 e DDD com zeros à esquerda (ex.: 0071 → 71). Somente os zeros do DDD não geram alerta. DDD ausente, incompleto e inexistente são problemas distintos. Fixo espera 8 dígitos e celular 9; as mensagens e os fatos trazem observado, esperado e diferença exata. Um excesso arbitrário não é convertido automaticamente em DDD incorporado. Evidências exibem `(DDD) número`.

Erros de e-mail descrevem o defeito encontrado (ex.: ausência de @, domínio incompleto, espaço interno, pontos consecutivos); não incluem a frase genérica “Informe apenas um endereço por campo”. Números de outros países, serviços especiais e ramais exigem tratamento separado. DDD/UF indica área de numeração, não residência atual.

## Excel e Power BI

Tratamento: usa os 23 campos alinhados ao layout comum, seguidos de extras preservados, e insere colunas coloridas de validação técnica, achados e sugestões por contato. Os valores não são corrigidos automaticamente. Datas reconhecidas têm exibição DD/MM/AAAA. Também inclui fotografia, origem, classificação contratual e status/timestamp do tratamento, além de campos manuais para o saneamento.

Power BI: `Fato_Registros` tem uma linha por registro/fotografia/execução. `Fato_Achados` tem uma linha por achado, com risco principal, problema específico, código e campos numéricos de dígitos. `Indicadores`, `Matriz_Risco` e `Recortes_Publico` ficam separados por `Data_Fotografia`; o último traz grupo/subgrupo × patrocinadora × plano. `Fontes` identifica cada arquivo/aba/cabeçalho/fotografia. `Execucao` identifica avaliação, processamento e escopo, separadamente da fotografia. O detalhe opcional `Fato_Contatos` contém um canal mapeado por registro, inclusive ausência. Todos os fatos levam `Data_Fotografia` como data Excel, não texto.

Exportações com mais de 25 mil linhas estimadas geram um ZIP com arquivos Excel separados por tabela e bloco, de até 25 mil linhas cada, sem truncamento. Cada arquivo repete o cabeçalho. Um arquivo Contexto contém execução, regras e indicadores, quando aplicável. Combine arquivos com o mesmo prefixo no Power Query, promovendo o cabeçalho antes de combinar. Exportações menores geram um único XLSX. A divisão reduz o consumo de memória e oferece blocos manejáveis para tratamento e Power BI.

Guarde cada Excel gerencial em uma pasta histórica. No Power BI, use “Obter dados > Pasta”, filtre os nomes das tabelas por prefixo e combine os arquivos. Crie a chave `Id_Execucao & "|" & Id_Registro` nos fatos para a relação 1:N de registros com achados e canais. Relacione `Execucao` por `Id_Execucao`. Não relacione apenas por pessoa: isso duplicaria vínculos e execuções.

Medidas sugeridas sobre Fato_Registros:

```dax
Registros = COUNTROWS(Fato_Registros)
Com erro = CALCULATE([Registros], Fato_Registros[Resultado] = "Inconsistente")
Taxa com erro = DIVIDE([Com erro], [Registros])
Com canal válido = CALCULATE([Registros], Fato_Registros[Cobertura] = "Com canal válido")
Cobertura técnica = DIVIDE([Com canal válido], [Registros])
Pessoas únicas = CALCULATE(DISTINCTCOUNT(Fato_Registros[Id_Pessoa]), Fato_Registros[Id_Pessoa] <> "")
```

Compare fotografias com versões, canais e regras equivalentes. Para várias execuções da mesma fotografia, escolha uma execução de referência por foto antes de consolidar: não some reprocessamentos. Use Data_Fotografia na dimensão de calendário da evolução; Data_Referencia/Processado_Em_UTC são metadados de avaliação/processamento. Não some pessoas únicas entre planos ou fotografias. Editar o Excel de tratamento não atualiza o aplicativo; os botões Tratado/Reabrir atualizam apenas o andamento em memória e os próximos arquivos exportados.

Veja `POWERBI_SUGESTAO.md`, `powerbi-preview.html` e `powerbi-preview.png` para tema, modelo, medidas e proposta para a Direção. Os valores e a tendência da prévia são sintéticos, não resultados históricos da base fornecida.

## Fontes técnicas

Tabela de DDDs e padrões consultados em 06/10/2026:

- Anatel — Plano de Numeração Brasileiro: https://www.gov.br/anatel/pt-br/regulado/numeracao/plano-de-numeracao-brasileiro
- Anatel — Perguntas frequentes de numeração: https://www.gov.br/anatel/pt-br/regulado/numeracao/perguntas-frequentes
- Anatel — Nono dígito: https://www.gov.br/anatel/pt-br/regulado/numeracao/codigos-nacionais/nono-digito

Regras internas de placeholders, compartilhamento, padronização e contexto são heurísticas de pré-validação, documentadas e configuráveis; não são prova de erro de titularidade.

## Privacidade e operação

Sem envio de dados, APIs, CDN ou telemetria. Bibliotecas, imagens e arquivos são locais. Bases, resultados e andamento ficam em memória; configuração e andamento só são salvos quando o usuário baixa o JSON. O andamento registra identidades de arquivo/linha/foto e assinaturas de escopo, sem valores dos contatos. O pacote contém código, documentação e demonstração/preview sintéticos, sem a base real.

XLS legado não é suportado. Fórmulas são lidas pelo valor armazenado; recalcule e salve a base antes de importar. Identificadores devem ser armazenados como texto para preservar zeros que já poderiam ter sido perdidos no arquivo de origem. Capacidade depende da memória disponível no navegador; exportações completas exigem mais memória que a visualização paginada.

## Evolução e testes

`src/schema.js` define campos/regras; `src/audit.js` contém avaliação e classificação; `src/workflow.js` gerencia concatenação, tratamento e filtros; `src/export.js` gera os fatos/Excels; `src/app.js` controla a interface. Testes: run-tests.cjs, audit-v1.1.cjs, workflow-v1.1.cjs, export-v1.1.cjs, ui-smoke.cjs e large-export.cjs, na pasta tests. A suíte de interação usa DOM simulado: verifica fluxo e conteúdo, não layout do navegador. A imagem da proposta PBI foi renderizada e inspecionada separadamente.

Versão 1.1.0. Identidade visual do HUB: Segoe UI, azul profundo, azul-petróleo e superfícies claras, com logos oficiais.
