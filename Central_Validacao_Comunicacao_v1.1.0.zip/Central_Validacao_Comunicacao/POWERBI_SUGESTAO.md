# Conexões em Foco — proposta para Power BI

O painel proposto responde três questões da Direção: qual é a qualidade estrutural dos contatos, em quais públicos concentrar o saneamento e se a qualidade evolui entre fotografias comparáveis. O progresso da fila de tratamento é mostrado separadamente do resultado original da auditoria.

Abra `powerbi-preview.html` para explorar a proposta com filtros. Todos os dados desse HTML são sintéticos e estão identificados como exemplos. A imagem `powerbi-preview.svg` apresenta o conceito visual. Nenhum dos dois representa indicadores calculados da base de referência.

## Tema e organização

- Nome: **Conexões em Foco — Qualidade dos Meios de Comunicação**.
- Azul profundo `#082847` para cabeçalhos; teal `#137B96` para séries de cobertura e tratamento; superfícies `#F2F6F9`; cartões brancos; texto `#183B57`.
- Segoe UI, disponível no Windows; títulos de 22–26 px, KPIs de 30–34 px, descrição de 11–12 px.
- Erros: `#BA493C`; pendências: `#B7791F`; melhora entre fotografias: `#23876C`. Evite usar apenas cor: acompanhe valores de rótulos.
- Página executiva de proporção 16:9, com data da fotografia, grupo, subgrupo, plano e patrocinadora no topo.
- Primeira linha: universo de registros, % com erro, % com ao menos um canal válido, pendentes de tratamento. Mostre o numerador e o denominador das taxas.
- Segunda linha: evolução da taxa de erro entre fotografias e avanço operacional (pendentes / tratados).
- Terceira linha: matriz hierárquica risco → problema específico e tabela de público → plano → patrocinadora, com quantidade, % de erro e pendentes.
- Páginas adicionais: “Canais & riscos” (DDD, fixos, celulares e e-mails) e “Tratamento” (fila, evidência, origem, responsável, ação e prazo se esses campos forem incorporados ao acompanhamento).

## Datas e granularidade

**Data_Fotografia** é a data a que o arquivo de origem se refere. Arquivos concatenados podem ter fotografias distintas. Para representar um único fechamento no painel, filtre a fotografia desejada e confira se o universo está completo. Não trate arquivos de períodos diferentes como participantes adicionais de uma mesma foto.

**Data_Referencia** é a data de avaliação escolhida para a execução. A idade e os controles de datas utilizam a **Data_Fotografia individual** de cada base. **Processado_Em_UTC** indica quando a auditoria foi executada. A Direção deve ver a fotografia, e as outras duas datas podem ficar em um tooltip ou quadro de rastreabilidade.

Fato_Registros tem uma linha por registro de origem e execução. Esse grão pode conter a mesma pessoa em mais de um plano ou mais de uma base. “Registros” e “Pessoas únicas” precisam de medidas distintas. A aplicação concatena bases; ela não escolhe automaticamente qual vínculo é o correto quando há sobreposição.

Se houver reprocessamentos da mesma fotografia, escolha explicitamente uma execução oficial por fotografia e escopo. Não some versões de processamento da mesma fotografia. Acumular Excel de uma mesma execução reexportado depois de marcar tratados também duplica o universo se não houver uma rotina de substituição ou seleção da carga mais recente.

## Classificação do público

O grupo **Ativos** contém: Ativo-Aguardando Deferimento, Ex-Aguardando Deferimento, Assistido-aguardando deferimento, Ativo, Remido, Autopatrocinado e Optante pelo BPO. Esses valores ficam como subgrupos.

O grupo **Assistidos** é subdividido pelo tipo de benefício: texto contendo `PENS`, sem distinguir maiúsculas de minúsculas, corresponde a **Pensionista**; os demais assistidos correspondem a **Aposentado(a)**. Valores sem classificação suficiente aparecem como **Não classificado**, para investigação. O grupo derivado não substitui a situação original.

## Modelo recomendado

Crie em Power Query a chave `Chave_Registro = Id_Execucao & "|" & Id_Registro` em Fato_Registros, Fato_Achados e Fato_Contatos. `Id_Registro` isolado não é uma chave entre execuções.

Crie dimensões com chaves sem duplicidade:

| Dimensão | Conteúdo / relação |
| --- | --- |
| Dim_Fotografia | calendário, dia, mês, ano; 1:* para Data_Fotografia nos fatos |
| Dim_Execucao | uma execução oficial por fotografia e escopo, versão e escopo das regras; 1:* nos fatos |
| Dim_Plano | Plano; 1:* em Fato_Registros e, se presente, nos demais fatos |
| Dim_Patrocinador | patrocinadora; 1:* em Fato_Registros e Fato_Achados |
| Dim_Publico | chave composta Grupo_Contratual + Subgrupo_Contratual; 1:* nos fatos |
| Dim_Regra | Id_Regra, regra, risco principal, severidade; 1:* em Fato_Achados |

Para permitir que filtros aplicados aos registros alcancem seus achados e canais, há duas alternativas. Uma implementação simples mantém Fato_Registros como tabela de registro única e cria relações 1:* de `Chave_Registro` para Fato_Achados e Fato_Contatos, sempre em uma única direção. Nesse desenho, conecte fotografia, execução, plano, patrocinadora e público **apenas a Fato_Registros**, para evitar caminhos ambíguos. Dim_Regra relaciona-se diretamente a Fato_Achados.

Uma implementação em estrela mais estrita pode enriquecer Fato_Achados e Fato_Contatos com as chaves dimensionais na preparação e conectar dimensões compartilhadas diretamente aos três fatos, **sem relações entre fatos**. O filtro de regra não deve reduzir a população do denominador de taxa de erro inadvertidamente.

Use as tabelas de fatos para medidas; `Indicadores`, `Matriz_Risco` e `Recortes_Publico` são resumos úteis para conciliação. Não some os totais de dimensões diferentes, nem derive pessoas únicas somando pessoas por plano.

## Medidas DAX de partida

Exemplos para o desenho simples com Fato_Registros filtrando achados/canais. Mantenha as medidas de registros na tabela de registros, sem contar linhas de Fato_Achados.

```dax
Registros = COUNTROWS(Fato_Registros)

Registros com erro =
CALCULATE([Registros], KEEPFILTERS(Fato_Registros[Erros] > 0))

% registros com erro = DIVIDE([Registros com erro], [Registros])

Registros com canal válido =
CALCULATE([Registros], KEEPFILTERS(Fato_Registros[Canais_Validos] > 0))

% cobertura técnica = DIVIDE([Registros com canal válido], [Registros])

Registros com achados =
CALCULATE([Registros], KEEPFILTERS(Fato_Registros[Erros] + Fato_Registros[Alertas] > 0))

Pendentes = SUM(Fato_Registros[Pendente])

Tratados = SUM(Fato_Registros[Tratado])

% tratados entre registros com achados =
DIVIDE([Tratados], [Registros com achados])

Achados = COUNTROWS(Fato_Achados)

Achados em registros pendentes =
CALCULATE([Achados], KEEPFILTERS(Fato_Achados[Pendente] = 1))

Registros afetados por achados =
DISTINCTCOUNT(Fato_Achados[Chave_Registro])

Pessoas únicas =
COUNTROWS(
    FILTER(
        VALUES(Fato_Registros[Id_Pessoa]),
        NOT ISBLANK(Fato_Registros[Id_Pessoa]) && Fato_Registros[Id_Pessoa] <> ""
    )
)
```

Para o indicador de variação, compare com a fotografia imediatamente anterior **disponível e oficial**, não necessariamente o mês anterior do calendário. Uma diferença de taxas deve ser exibida em pontos percentuais, por exemplo de 12% para 10% = −2 p.p. Registre diferenças de versão, regras, universo, planos e patrocinadoras antes de atribuir a mudança a uma melhora cadastral.

## Matriz para atuação em lote

Linhas: `Risco_Principal` → `Problema_Especifico` → `Campo`. Valores: achados, registros afetados e achados em registros pendentes. Tooltip: severidade, regra, dígitos observados/esperados/faltantes/excedentes e exemplos com proteção adequada ao público do relatório.

DDDs com zeros à esquerda, como `0071`, são normalizados para `71` e não devem formar um risco de padronização. DDD ausente, inexistente ou com quantidade inválida recebe problema próprio. Para telefone/celular, use a contagem exata de dígitos faltantes ou excedentes, sem agrupar todos como “incompleto”.

## Leitura correta do resultado

- **Qualidade estrutural:** resultado das regras no instante da auditoria. As taxas se baseiam nos registros originais.
- **Cobertura técnica:** existência de pelo menos um contato no formato técnico aceito. Não comprova linha ativa, entrega de e-mail ou titularidade.
- **Tratamento:** acompanhamento de decisão/ação. Marcar um registro como tratado não apaga erros ou alertas daquela fotografia.
- **Evolução cadastral:** precisa de novas fotografias oficiais, com universo e escopo comparáveis. O HTML apresenta apenas a proposta desse acompanhamento.

Antes de publicar à Direção, concilie contagens por fotografia, plano e patrocinadora com os Excels; valide chaves, duplicações entre bases e grupos não classificados. Restrinja as páginas executivas a dados agregados e ofereça o detalhe nominal somente ao público operacional autorizado.
